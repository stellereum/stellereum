#!/usr/bin/env python3
"""2PC witness-layer refinement check.

Abstract machine (P5): source/target phases N,P,C,A with message-guarded
transitions.  Concrete layer (src/sharding.rs, src/runtime.rs,
src/state_engine.rs):

  * VALIDATE (propose/validate) -> `xpc_admissible` -> `verify_xpc_anchored`
    (proof + finalized-header anchor);
  * APPLY (state engine)        -> `verify_xpc_proof` (proof only, NO anchor).

We show:
  1. the abstract guards and the `xpc_admissible` phase sets agree;
  2. an attacker-chosen `source_state_root` passes the proof-only check but
     fails the anchored check, so the APPLY path alone would credit a forged
     PREPARED/ABORTED leaf.
  3. therefore the refinement obligation is: every block reaching APPLY has
     passed VALIDATE (or carries a QC from an honest quorum).  The gap is the
     apply/reorg path if it can skip VALIDATE.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "xpc_refinement.json")

N, P, C, A = "N", "P", "C", "A"


# --------------------------------------------------------------------------
# 1. Abstract machine (from P5) + admissible phase sets
# --------------------------------------------------------------------------
# kind -> (accepted proof phases, abstract guard description)
ADMISSIBLE = {
    "Prepare":        (["Prepared"],                    "source account leaf OR source Prepared"),
    "PrepareAck":     (["Prepared"],                    "target Prepared (voted YES)"),
    "Commit":         (["Prepared", "Committed"],       "source Prepared/Committed (escrow)"),
    "AbortRequest":   (["Prepared", "Committed"],       "source Prepared/Committed"),
    "AbortAck":       (["Aborted"],                     "target Aborted (never prepared)"),
}


def abstract_transitions():
    """Enumerate the coupled reachable states with the P5 guards."""
    start = (N, N)
    seen = {start}
    frontier = [start]
    while frontier:
        s, t = frontier.pop()
        moves = []
        if s == N:
            moves.append((P, t, "source_prepare"))
        if s in (P, C) and t in (N, P):
            moves.append((s, P, "target_prepare"))
        if s == P and t in (P, C):
            moves.append((C, t, "source_on_prepare_ack"))
        if s == P and t in (N, A):
            moves.append((A, t, "source_on_abort_ack"))
        if s in (P, C) and t == P:
            moves.append((s, C, "target_on_commit"))
        if s in (P, A) and t == N:
            moves.append((s, A, "target_on_abort_request"))
        for ns, nt, _ in moves:
            if (ns, nt) not in seen:
                seen.add((ns, nt))
                frontier.append((ns, nt))
    return sorted([list(x) for x in seen])


# --------------------------------------------------------------------------
# 2. Proof-only vs anchored verification
# --------------------------------------------------------------------------
def proof_ok(root, key, value, proof):
    """Toy one-level Merkle proof: leaf = H(key||value), root = H(leaf||proof)."""
    import hashlib
    leaf = hashlib.sha256(key + value).digest()
    h = hashlib.sha256()
    h.update(leaf)
    h.update(proof)
    return h.digest() == root


def anchor_ok(root, finalized_roots):
    return root in finalized_roots


def apply_record(phase, root, finalized_roots, anchored):
    """Return (accepted, credited/refunded) for a forged COMMIT/ABORT-ACK."""
    key = b"xpc-key"
    value = phase.encode()
    proof = b"proof"
    valid = proof_ok(root, key, value, proof)
    if anchored:
        return (valid and anchor_ok(root, finalized_roots), False)
    return (valid, True)  # proof-only path: forged leaf accepted


# --------------------------------------------------------------------------
# 3. Attack: forged source root
# --------------------------------------------------------------------------
def attack():
    import hashlib
    # attacker builds a trie whose root commits to a fake Prepared leaf:
    # root = H(key || value || proof), so the proof verifies by construction.
    key, value, proof = b"xpc-key", b"Prepared", b"proof"
    leaf = hashlib.sha256(key + value).digest()
    h = hashlib.sha256(); h.update(leaf); h.update(proof)
    fake_root = h.digest()
    honest_finalized = {hashlib.sha256(b"honest-root").digest()}
    forged_commit = apply_record("Prepared", fake_root, honest_finalized,
                                 anchored=False)
    anchored_commit = apply_record("Prepared", fake_root, honest_finalized,
                                   anchored=True)
    return {
        "fake_root_is_finalized": fake_root in honest_finalized,
        "apply_proof_only": {"accepted": forged_commit[0],
                             "credited": forged_commit[1]},
        "apply_anchored": {"accepted": anchored_commit[0],
                           "credited": anchored_commit[1]},
        "verdict": "proof-only APPLY credits a forged PREPARED leaf; the "
                   "anchored VALIDATE path rejects it",
    }


def run():
    return {
        "admissible": ADMISSIBLE,
        "abstract_states": abstract_transitions(),
        "attack": attack(),
        "refinement_obligations": [
            "R1: every block reaching state_engine::apply_xpc_record has "
            "passed runtime::xpc_admissible (propose/validate) or is covered "
            "by a QC from an honest quorum.",
            "R2: xpc_state_key/value bind (tx_hash, phase); a leaf for one "
            "phase cannot satisfy another phase's proof (domain separation).",
            "R3: PatriciaTrie::verify_merkle_proof is sound; SHA-256 collision "
            "resistance.",
            "R4: FinalizedHeaderRegistry::anchor_holds returns true only for a "
            "locally finalized header of the peer shard.",
            "R5: apply/reorg paths do not bypass VALIDATE (the gap to close).",
        ],
        "gap": {
            "where": "src/state_engine.rs:6433-6522 uses verify_xpc_proof "
                     "(proof only); src/runtime.rs:1732 xpc_admissible uses "
                     "verify_xpc_anchored (proof + anchor).",
            "risk": "if any apply/sync/reorg path skips xpc_admissible, a "
                    "Byzantine source can forge source_state_root + proof and "
                    "the target credits/refunds a fake phase.",
            "fix": "re-run xpc_admissible (or at least verify_xpc_anchored) "
                   "inside apply_xpc_record, or prove/enforce that apply only "
                   "sees validated blocks.",
        },
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
