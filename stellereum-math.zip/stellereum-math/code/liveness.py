#!/usr/bin/env python3
"""Liveness / view-change timing: is the linear timeout ladder optimal?

Model (explicit, so the theorem is falsifiable):
  * A round succeeds iff the proposer's message arrives within T, X <= T,
    where X ~ Pareto(x0, gamma) (heavy tail; p50 = x0 * 2^(1/gamma)).
  * A failed round costs T (wait) + c (view-change / re-proposal overhead).
  * BASE MODEL: rounds are iid.
  * PERSISTENT MODEL: a hidden two-state (fast/slow) network persists across
    rounds; a timeout is evidence of the slow state.

Claims tested:
  T1 (iid): the expected time-to-finality is minimised by a CONSTANT timeout
            (rho = 1); any rho > 1 is worse.  Closed form
                T* = x0 * (gamma + 1)^(1/gamma)        (c = 0)
            and a numeric optimum for c > 0.
  T2 (persistent): the optimal schedule is geometric with rho > 1, which is
            what a view-change ladder is for.
So a ladder is justified only by persistence, not by iid jitter; and its
constants should be derived from the latency tail, not hard-coded.
"""
import json
import math
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "liveness.json")
random.seed(20261105)


def pareto(x0, gamma):
    return x0 / (random.random() ** (1.0 / gamma))


def sim_schedule(T, gamma, x0, c, trials, rounds_max=300):
    total = 0.0
    for _ in range(trials):
        r = 0
        while True:
            t = T(r)
            x = pareto(x0, gamma)
            if x <= t:
                total += x
                break
            total += t + c
            r += 1
            if r >= rounds_max:
                total += t
                break
    return total / trials


def sim_persistent(T, g_fast, slow_factor, x0, c, trials, p_fast=0.9,
                   p_slow=0.97, p_start_slow=0.05, rounds_max=60):
    """Hidden persistent state: in the slow state every latency is scaled by
    slow_factor (same tail exponent), so a timeout is evidence of slowness."""
    total = 0.0
    for _ in range(trials):
        slow = random.random() < p_start_slow
        r = 0
        while True:
            t = T(r)
            x = pareto(x0 * (slow_factor if slow else 1.0), g_fast)
            if x <= t:
                total += x
                break
            total += t + c
            r += 1
            slow = (random.random() < p_slow) if slow else (random.random() > p_fast)
            if r >= rounds_max:
                total += t
                break
    return total / trials


def current_ladder(r):
    return 3000 + min(500 * r, 10_000)


def E_const(T, gamma, x0, c):
    """Exact expected time to finality for a constant timeout T.

    V = [ I(T) + (T + c) q ] / p,   q = (x0/T)^gamma,  p = 1 - q,
    I(T) = E[X * 1{X<=T}] = gamma x0^gamma (T^(1-gamma) - x0^(1-gamma))/(1-gamma).
    This is the Bellman fixed point  V = min_T { C(T) + q V }.
    """
    if T <= x0:
        return float("inf")
    q = (x0 / T) ** gamma
    p = 1.0 - q
    I = gamma * x0 ** gamma * (T ** (1 - gamma) - x0 ** (1 - gamma)) / (1 - gamma)
    return (I + (T + c) * q) / p


def optimal_constant(gamma, x0, c):
    best = (float("inf"), None)
    for i in range(1, 6000):
        t = x0 * (1.0 + i / 500.0)
        e = E_const(t, gamma, x0, c)
        if e < best[0]:
            best = (e, t)
    return best


def E_geometric(T0, rho, gamma, x0, c, rounds=80):
    """Exact expected cost of the non-stationary schedule T_r = T0 rho^r."""
    Q, E = 1.0, 0.0
    for r in range(rounds):
        T = T0 * rho ** r
        q = (x0 / T) ** gamma
        p = 1.0 - q
        I = gamma * x0 ** gamma * (T ** (1 - gamma) - x0 ** (1 - gamma)) / (1 - gamma)
        E += Q * (I + (T + c) * q)
        Q *= q
        if Q < 1e-18:
            break
    return E


def optimal_geometric(gamma, x0, c, T0s=None, rhos=None):
    if T0s is None:
        T0s = [x0 * (0.5 + 0.05 * i) for i in range(0, 201)]
    if rhos is None:
        rhos = [1.0 + 0.01 * j for j in range(0, 201)]
    best = (float("inf"), None, None)
    for T0 in T0s:
        for rho in rhos:
            e = E_geometric(T0, rho, gamma, x0, c)
            if e < best[0]:
                best = (e, T0, rho)
    return best


def optimal_geometric_persistent(c=500, trials=15_000):
    x0 = 660.0 / math.sqrt(2)
    best = (float("inf"), None, None)
    for T0 in [1200, 2400, 3600, 4800, 6000]:
        for j in range(0, 101):
            rho = 1.0 + 0.02 * j
            e = sim_persistent(lambda r, T0=T0, rho=rho: T0 * rho ** r,
                               2.0, 4.0, x0, c, trials=trials)
            if e < best[0]:
                best = (e, T0, rho)
    return best


def run():
    out = {"median_ms": 660, "c_values_ms": [0, 250, 500, 1000], "by_gamma": []}
    for gamma in [1.5, 2.0, 2.5]:
        x0 = 660.0 / (2.0 ** (1.0 / gamma))
        row = {
            "gamma": gamma,
            "x0_ms": x0,
            "p99_ms": x0 * (100 ** (1.0 / gamma)),
            "mean_ms": (x0 * gamma / (gamma - 1)),
            "T_star_c0_ms": (x0 * (2 + 3 ** 0.5) if abs(gamma - 2.0) < 1e-9
                             else optimal_constant(gamma, x0, 0.0)[1]),
            "cases": [],
        }
        for c in out["c_values_ms"]:
            e_cur = sim_schedule(current_ladder, gamma, x0, c, trials=120_000)
            e_const, t_star = optimal_constant(gamma, x0, c)
            e_const_sim = sim_schedule(lambda r, t=t_star: t, gamma, x0, c,
                                       trials=120_000)
            row["cases"].append({
                "c_ms": c,
                "E_current_ladder_ms": round(e_cur, 2),
                "E_constant_opt_ms": round(e_const, 2),
                "T_star_ms": round(t_star, 1),
                "E_constant_opt_sim_ms": round(e_const_sim, 2),
                "speedup_vs_ladder": round(e_cur / e_const, 3),
            })
        out["by_gamma"].append(row)

    gamma, c = 2.0, 500
    x0 = 660.0 / math.sqrt(2)
    e_const, t_star = optimal_constant(gamma, x0, c)
    e_g, T0, rho = optimal_geometric(gamma, x0, c)
    out["iid_geometric_opt"] = {
        "gamma": gamma, "c_ms": c, "T0_ms": T0, "rho": rho,
        "E_ms": round(e_g, 2), "E_constant_opt_ms": round(e_const, 2),
        "constant_T_star_ms": round(t_star, 1),
        "conclusion": "Bellman: under iid latency the optimal policy is constant (rho*=1)",
    }
    e_p, T0_p, rho_p = optimal_geometric_persistent()
    e_const_p = min(sim_persistent(lambda r, t=t: t, 2.0, 4.0,
                                   x0, 500, trials=40_000)
                    for t in [3200, 4800, 6400, 9600, 12800])
    out["persistent_model"] = {
        "gamma_fast": 2.0, "slow_factor": 4.0, "c_ms": 500,
        "T0_star_ms": T0_p, "rho_star": round(rho_p, 3),
        "E_geometric_ms": round(e_p, 2),
        "E_best_constant_ms": round(e_const_p, 2),
        "gain_vs_constant_pct": round(100 * (e_const_p - e_p) / e_const_p, 2),
        "conclusion": "rho*>1: backoff is justified under persistence",
    }
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
