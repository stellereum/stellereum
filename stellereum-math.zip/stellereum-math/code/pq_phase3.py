#!/usr/bin/env python3
"""Phase-3 PQ results:

  A. Probabilistic QC verification: exact detection probability, the
     "one bad signature" lower bound, and the economic bond.
  B. Proactive threshold MEV: secrecy lifetime with a mobile adversary and
     the refresh interval.
  C. Multi-target quantum hash security (MMR/epoch roots): n/3 - log2 M.
  D. XMSS-VRF grinding economics: the slashing condition.
  E. Lattice aggregation norm blow-up: sqrt(k) growth and security loss.
"""
import json
import math
import os
from math import comb, log2

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "pq_phase3.json")


# --------------------------------------------------------------------------
# A. Sampling a QC
# --------------------------------------------------------------------------
def detect_prob(k, e, s):
    """P[at least one of the e bad indices is in a uniform s-subset]."""
    if s >= k:
        return 1.0
    if k - e < s:
        return 1.0
    return 1.0 - comb(k - e, s) / comb(k, s)


def samples_for_fraction(eps, delta):
    """s with (1-eps)^s <= delta."""
    if eps <= 0:
        return None
    return math.ceil(math.log(delta) / math.log(1 - eps))


def sampling_table():
    rows = []
    for delta_bits in [40, 64, 80]:
        delta = 2.0 ** (-delta_bits)
        row = {"delta_bits": delta_bits}
        for eps in [0.5, 1 / 3, 0.1, 0.05, 0.01]:
            row[f"eps={eps:.3f}"] = samples_for_fraction(eps, delta)
        rows.append(row)
    # the e=1 lower bound: s >= k(1-delta)
    one = []
    for k in [64, 128, 256, 512, 1024]:
        one.append({
            "k": k,
            "s_needed_one_bad_delta_2^-40": math.ceil(k * (1 - 2.0 ** -40)),
            "detection_at_s=k/2": detect_prob(k, 1, k // 2),
        })
    # economic bond: B > V (1-Pdet)/Pdet
    bonds = []
    for k in [64, 256, 1024]:
        for s in [16, 32, 64, 128]:
            if s > k:
                continue
            pdet = detect_prob(k, 1, s)
            bonds.append({"k": k, "s": s, "P_det_one_bad": pdet,
                          "bond_over_value": (1 - pdet) / pdet if pdet else None})
    return {"fraction_table": rows, "one_bad": one, "bond": bonds}


# --------------------------------------------------------------------------
# B. Proactive threshold with a mobile adversary
# --------------------------------------------------------------------------
def proactive_table():
    out = {"lifetime_without_refresh": [], "refresh_interval": []}
    for t in [2, 5, 10, 20, 34]:
        for f in [1, 2, 3]:
            if f >= t:
                continue
            out["lifetime_without_refresh"].append({
                "t": t, "f_per_epoch": f,
                "T_epochs_secrecy": (t - 1) // f,
                "breaks_at_epoch": (t - 1) // f + 1,
            })
    # mobile adversary: corrupts lambda*n per epoch; refresh every Delta epochs.
    # Solve for the largest Delta with P[Bin(n, lambda*Delta) >= t] <= delta.
    def max_delta(n, t, lam, delta):
        lo, hi = 1e-9, 1e7
        for _ in range(200):
            mid = (lo + hi) / 2
            p = min(lam * mid, 1.0)
            fail = sum(comb(n, x) * p ** x * (1 - p) ** (n - x)
                       for x in range(t, n + 1))
            if fail <= delta:
                lo = mid
            else:
                hi = mid
        return lo

    for n, t, lam in [(100, 34, 0.01), (100, 34, 0.05),
                      (100, 34, 0.10), (200, 67, 0.05)]:
        for delta_bits in [40, 20, 7]:
            delta = 2.0 ** (-delta_bits)
            d = max_delta(n, t, lam, delta)
            p = min(lam * d, 1.0)
            fail = sum(comb(n, x) * p ** x * (1 - p) ** (n - x)
                       for x in range(t, n + 1))
            out["refresh_interval"].append({
                "n": n, "t": t, "lambda_per_epoch": lam,
                "delta_bits": delta_bits,
                "Delta_star": round(d, 3),
                "p_corrupt_per_interval": round(p, 4),
                "P[fail]": fail,
                "refresh_bytes_per_epoch_32B": n * n * 32,
            })
    return out


# --------------------------------------------------------------------------
# C. Multi-target quantum hash security
# --------------------------------------------------------------------------
def multi_target():
    rows = []
    for nbits in [256, 384, 512]:
        for logM in [0, 10, 20, 30]:
            rows.append({
                "hash_bits": nbits,
                "log2_targets": logM,
                "collision_bits": nbits / 3 - logM,
                "preimage_bits": nbits / 2 - logM,
            })
    return rows


# --------------------------------------------------------------------------
# D. XMSS-VRF grinding economics
# --------------------------------------------------------------------------
def grinding_economics():
    rows = []
    for p in [0.001, 0.01, 0.064, 0.1]:
        rows.append({
            "p_one_signature": p,
            "max_gain_factor_over_single": (1 - p) / p,
            "min_slashing_over_reward": 1 - p,
            "slashing_suffices_if_S_gt_R_times": 1 - p,
        })
    return rows


# --------------------------------------------------------------------------
# E. Lattice aggregation norm blow-up
# --------------------------------------------------------------------------
def aggregation():
    rows = []
    for k in [4, 16, 64, 256, 1024]:
        rows.append({
            "k": k,
            "worst_case_norm_factor": k,
            "random_norm_factor": math.sqrt(k),
            "security_loss_bits_random": 0.5 * log2(k),
            "verification_bound_must_grow_by": math.sqrt(k),
        })
    return rows


def run():
    return {
        "sampling": sampling_table(),
        "proactive": proactive_table(),
        "multi_target": multi_target(),
        "grinding_economics": grinding_economics(),
        "aggregation": aggregation(),
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
