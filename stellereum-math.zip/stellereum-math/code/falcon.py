#!/usr/bin/env python3
"""Falcon-512 / 1024 concrete security and quorum-certificate size math.

Lattice: NTRU, dimension 2n, determinant q^n (q = 12289).
Gaussian heuristic shortest vector:
    GH = sqrt(2n/(2*pi*e)) * q^(1/2) = sqrt(n/(pi*e)) * sqrt(q).
A signature is a lattice vector of norm about sigma*sqrt(2n); Falcon accepts
up to beta = sqrt(beta^2).  A forgery needs a lattice vector of norm <= beta,
found by BKZ with root-Hermite factor
    delta = (beta / q^(1/2))^(1/(2n)).
We invert the BKZ delta(beta_block) curve and price it with core-SVP.

Also: QC size = k * |sig|; succinct-proof crossover k* = |proof|/|sig|.
"""
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "falcon.json")


def delta_bkz(b):
    return ((math.pi * b) ** (1.0 / b) * b / (2 * math.pi * math.e)) ** (1.0 / (2 * (b - 1)))


def invert_delta(target, lo=50, hi=4000):
    """delta(b) is decreasing for b >= ~50; return the block size with
    delta(b) closest to target."""
    best = (float("inf"), None)
    for b in range(lo, hi + 1):
        e = abs(delta_bkz(b) - target)
        if e < best[0]:
            best = (e, b)
    return best[1]


def analyze(name, n, q, beta2, sigma, sig_bytes):
    dim = 2 * n
    det_root = q ** 0.5
    GH = math.sqrt(dim / (2 * math.pi * math.e)) * det_root
    beta = math.sqrt(beta2)
    delta = (beta / det_root) ** (1.0 / dim)
    bb = invert_delta(delta)
    return {
        "name": name, "n": n, "q": q, "dim": dim,
        "sigma": sigma, "beta": beta,
        "sig_norm_mean_sigma_sqrt_2n": sigma * math.sqrt(dim),
        "GH": GH, "beta_over_GH": beta / GH,
        "root_hermite_delta": delta,
        "bkz_block_size": bb,
        "core_svp_classical_bits": round(0.292 * bb, 1),
        "core_svp_quantum_bits": round(0.265 * bb, 1),
        "signature_bytes": sig_bytes,
    }


def run():
    out = {"lattices": [
        analyze("Falcon-512", 512, 12289, 34034726, 165.7366171829776, 666),
        analyze("Falcon-1024", 1024, 12289, 70265242, 168.38857144654395, 1280),
    ]}
    # QC sizes and succinct-proof crossover
    qc = []
    for k in [1, 4, 16, 64, 105, 128, 256, 512, 1024]:
        qc.append({
            "k": k,
            "raw_falcon512_bytes": k * 666,
            "with_32B_bitmap_bytes": k * 666 + k // 8,
        })
    out["qc_size"] = qc
    cross = []
    for proof_kb in [20, 50, 100, 200, 500]:
        cross.append({
            "proof_kb": proof_kb,
            "crossover_k_vs_falcon512": round(proof_kb * 1024 / 666, 1),
        })
    out["succinct_proof_crossover"] = cross
    # deterministic-signature VRF: output/verification sizes
    out["pq_vrf_candidate"] = {
        "construction": "y = H(seed || pk); pi = Falcon.Sign_det(sk, H(seed||pk)); "
                        "verify(pk, seed, y, pi): Falcon.Verify(pk, H(seed||pk), pi) "
                        "and y == H(seed||pk)",
        "proof_bytes": 666,
        "output_bytes": 32,
        "security_reduction": "EUF-CMA(Falcon) + PRF(H) in ROM; "
                              "pseudorandomness holds only if the signing algorithm "
                              "is deterministic (a randomized signer can grind pi).",
        "rollback_risk": "Falcon samples from a discrete Gaussian; a DETERMINISTIC "
                         "nonce derived from (sk, message) is required.  Lattice "
                         "hash-and-sign has no ECDSA-style nonce-reuse key leak, but "
                         "determinism must be audited for side channels.",
    }
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
