#!/usr/bin/env python3
"""Stateful XMSS-VRF hardening.

Adds the production-critical piece the prototype lacked: a monotone leaf
counter.  A leaf is used at most once; re-signing the same epoch is refused
BEFORE the one-time key is touched, so grinding through the API is impossible
(an implementation that bypasses the counter burns the WOTS+ key and is
slashable, per P10/P14).

Also benchmarks h=6 and h=10 and reports the signature size.
"""
import json
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "xmss_vrf_stateful.json")

import xmss_vrf as base  # noqa: E402


class StatefulXMSS:
    def __init__(self, master, height):
        self.master = master
        self.height = height
        self.levels = base.build_tree(master, height)
        self.root = self.levels[-1][0]
        self.next_leaf = 0
        self.used = set()

    def sign(self, epoch, msg):
        if epoch != self.next_leaf:
            raise ValueError(
                f"leaf {epoch} is not the next leaf {self.next_leaf} "
                f"(stateful XMSS refuses reuse)")
        if epoch in self.used:
            raise ValueError(f"leaf {epoch} already used")
        sig = base.xmss_sign(self.master, epoch, msg, self.levels)
        self.used.add(epoch)
        self.next_leaf += 1
        return sig

    def vrf(self, epoch, seed):
        sig = self.sign(epoch, seed)
        y = base.H(b"\x07", seed, b"".join(sig["wots"]))
        return y, sig

    def verify(self, epoch, x, y, sig):
        return base.vrf_verify(self.root, epoch, x, y, sig, self.height)


def bench(height, trials=3):
    master = b"stateful-xmss-demo"
    t0 = time.time()
    st = StatefulXMSS(master, height)
    build_ms = (time.time() - t0) * 1000
    t0 = time.time()
    y, sig = st.vrf(0, b"seed-0")
    sign_ms = (time.time() - t0) * 1000
    ok = st.verify(0, b"seed-0", y, sig)
    return {
        "height": height,
        "leaves": 1 << height,
        "build_ms": round(build_ms, 1),
        "sign_ms": round(sign_ms, 2),
        "verify": ok,
        "signature_bytes": len(b"".join(sig["wots"])) + len(b"".join(sig["auth"])),
        "public_key_bytes": len(st.root),
    }


def run():
    master = b"stateful-xmss-demo"
    st = StatefulXMSS(master, 6)
    y0, s0 = st.vrf(0, b"seed-0")
    ok0 = st.verify(0, b"seed-0", y0, s0)

    reuse_refused = False
    try:
        st.vrf(0, b"seed-0")  # same leaf again
    except ValueError:
        reuse_refused = True

    y1, s1 = st.vrf(1, b"seed-1")
    ok1 = st.verify(1, b"seed-1", y1, s1)
    wrong_epoch = not st.verify(2, b"seed-1", y1, s1)

    return {
        "stateful": {
            "first_sign_ok": ok0,
            "second_sign_same_leaf_refused": reuse_refused,
            "next_leaf_ok": ok1,
            "wrong_epoch_rejected": wrong_epoch,
            "next_leaf_after": st.next_leaf,
        },
        "benchmark": [bench(6), bench(8), bench(10)],
        "note": "the leaf counter makes grinding through the API impossible; "
                "bypassing it burns the WOTS+ key (P10/P14).",
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
