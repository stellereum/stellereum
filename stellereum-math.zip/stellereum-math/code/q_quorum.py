#!/usr/bin/env python3
"""Quorum-intersection audit for Stellereum.

Answers two questions *exactly* (exhaustive enumeration, small n):

  1. Which integer threshold t(n) is the SMALLEST one that guarantees that two
     conflicting quorum certificates share an HONEST signer when the Byzantine
     set B satisfies |B| < n/3 ?
  2. The code's two curves are
        consensus: floor(2n/3) + 1      (src/consensus.rs)
        bridge:    ceil(2n/3)           (src/bridge.rs)
     Which of them satisfy (1), and for which n do they fail?

We also test the weighted two-tier micro-committee rule
    T = max( floor(2*Wc/3)+1, floor(Wn/2)+1 )
against the correct weighted rule  t > (W + B)/2.

All results are printed as JSON to results/q_quorum.json.
"""
import json
import itertools
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "q_quorum.json")


def consensus_q(n: int) -> int:
    return (2 * n) // 3 + 1


def bridge_q(n: int) -> int:
    return (2 * n + 2) // 3  # ceil(2n/3)


def subsets_of_size(n, k):
    return itertools.combinations(range(n), k)


def unsafe_exists(n, t, B):
    """True iff two certificate sets S,T of size >= t exist with no honest
    validator in S∩T (i.e. (S∩T) ⊆ B).  Certificates are subsets of V."""
    V = set(range(n))
    B = set(B)
    honest = V - B
    # S\B and T\B must be disjoint; S,T each need >= t total signers.
    # Equivalently: choose disjoint honest parts A,Bp and fill the rest from B.
    # Enumerate signer sets directly for n <= 10.
    signers = [frozenset(c) for k in range(t, n + 1) for c in subsets_of_size(n, k)]
    for S in signers:
        for T in signers:
            if (S & T) <= B:
                return True, sorted(S), sorted(T)
    return False, None, None


def minimal_safe_threshold(n, byz_frac=1 / 3):
    """Smallest t such that every B with |B| < byz_frac*n is safe."""
    maxB = 0
    while (maxB + 1) < byz_frac * n:
        maxB += 1
    # if maxB >= byz_frac*n, reduce; exact integer condition |B| < n/3
    maxB = max(b for b in range(n + 1) if b < n / 3) if n > 0 else 0
    for t in range(0, n + 1):
        ok = True
        for bsz in range(0, maxB + 1):
            for B in subsets_of_size(n, bsz):
                if unsafe_exists(n, t, B)[0]:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            return t, maxB
    return None, maxB


def formula_threshold(n, byz_frac=1 / 3):
    # smallest integer t with t > (n + Bmax)/2
    Bmax = max(b for b in range(n + 1) if b < byz_frac * n)
    return (n + Bmax) // 2 + 1


def run_unweighted(nmax=9):
    rows = []
    for n in range(1, nmax + 1):
        tmin, Bmax = minimal_safe_threshold(n)
        f = formula_threshold(n)
        t_cons = consensus_q(n)
        t_bridge = bridge_q(n)
        # does each code curve satisfy the exact criterion?
        def curve_safe(t):
            for bsz in range(0, Bmax + 1):
                for B in subsets_of_size(n, bsz):
                    ok, S, T = unsafe_exists(n, t, B)
                    if ok:
                        return False, bsz, S, T
            return True, None, None, None

        sc = curve_safe(t_cons)
        sb = curve_safe(t_bridge)
        rows.append({
            "n": n,
            "max_byzantine": Bmax,
            "min_safe_threshold_exact": tmin,
            "closed_form": f,
            "consensus_q": t_cons,
            "consensus_safe": sc[0],
            "consensus_counterexample": None if sc[0] else {"B_size": sc[1]},
            "bridge_q": t_bridge,
            "bridge_safe": sb[0],
            "bridge_counterexample": None if sb[0] else {
                "B_size": sb[1], "S": sb[2], "T": sb[3]},
        })
    return rows


def weighted_intersection(W_total, B_weight, t):
    """A threshold t is safe iff 2t - W_total > B_weight (so the guaranteed
    intersection weight exceeds the whole Byzantine weight)."""
    return 2 * t - W_total > B_weight


def run_weighted_examples():
    """Two concrete counterexamples for the micro-committee rule."""
    out = []
    # W = 100 units of stake, Byzantine B = 33 (< 1/3).
    W, B = 100, 32
    for t in [51, 67]:
        out.append({
            "W": W, "B": B, "threshold": t,
            "guaranteed_intersection_weight": max(0, 2 * t - W),
            "safe": weighted_intersection(W, B, t),
        })
    # Explicit split showing the W=100/B=33 attack at t = 51.
    # attacker signs both certs (weight 33 on each), honest 67 split 18/18.
    # Each cert = 33 (Byz) + 18 (honest) = 51.
    attack = {
        "W": W, "B": B, "t": 51,
        "cert_A_signers": {"byzantine": 32, "honest": 19},
        "cert_B_signers": {"byzantine": 32, "honest": 19},
        "honest_total": 68,
        "honest_used": 38,
        "honest_idle": 30,
        "intersection_weight": 32,
        "intersection_is_all_byzantine": True,
        "both_certs_valid": 51 >= 51,
    }
    # cross-tier: micro (floor(W/2)+1) vs full (floor(2W/3)+1)
    q_full = consensus_q(W)
    q_micro = W // 2 + 1
    cross_intersection = max(0, q_micro + q_full - W)
    out.append({
        "cross_tier": {
            "q_micro": q_micro, "q_full": q_full, "W": W, "B": B,
            "guaranteed_cross_intersection_weight": cross_intersection,
            "safe": cross_intersection > B,
        }
    })
    return {"threshold_table": out, "explicit_attack": attack}


def hyper_capture_prob(n_validators, k, A, q_share):
    """Exact P[seats >= q_share*k + 1] when A of n validators are adversarial
    and k seats are drawn WITHOUT replacement (hypergeometric)."""
    from math import comb
    need = int(q_share * k) + 1
    denom = comb(n_validators, k)
    num = 0
    for x in range(need, min(k, A) + 1):
        if k - x <= n_validators - A:
            num += comb(A, x) * comb(n_validators - A, k - x)
    return num / denom


def committee_capture_prob(k, alpha, q_share):
    """P[Bin(k, alpha) >= ceil(q_share*k)] exactly, with rational-free floats."""
    from math import comb
    need = int(q_share * k) + 1
    if need > k:
        return 0.0
    p = 0.0
    for x in range(need, k + 1):
        p += comb(k, x) * (alpha ** x) * ((1 - alpha) ** (k - x))
    return p


def kl(p, q):
    return p * __import__("math").log(p / q) + (1 - p) * __import__("math").log((1 - p) / (1 - q))


def min_k_for_eps(alpha, eps, bound=False):
    """Smallest committee size k with P[Bin(k,alpha) > 2k/3] <= eps."""
    import math
    if bound:
        return math.ceil(math.log(1 / eps) / kl(2 / 3, alpha))
    k = 1
    while committee_capture_prob(k, alpha, 2 / 3) > eps:
        k += 1
    return k


def run_capture_table():
    rows = []
    for k in [16, 32, 64, 100, 128, 160, 200, 256]:
        rows.append({
            "k": k,
            "alpha=1/3,P[>=2/3]": committee_capture_prob(k, 1 / 3, 2 / 3),
            "alpha=0.30,P[>=2/3]": committee_capture_prob(k, 0.30, 2 / 3),
            "alpha=0.25,P[>=2/3]": committee_capture_prob(k, 0.25, 2 / 3),
        })
    targets = []
    for eps_bits in [40, 64, 80, 128]:
        eps = 2.0 ** (-eps_bits)
        for alpha in [1 / 3, 0.30, 0.25]:
            targets.append({
                "target_bits": eps_bits,
                "alpha": alpha,
                "k_exact": min_k_for_eps(alpha, eps),
                "k_chernoff_upper": min_k_for_eps(alpha, eps, bound=True),
            })
    return {"by_size": rows, "min_k": targets}


def run_vrf():
    """VRF sortition: seat law, capture probability, optimal committee size."""
    out = {}
    # E[seats] and Var for one validator with stake fraction p = k/n
    out["seat_law"] = {
        "note": "equal stakes, tickets iid: seats ~ Binomial(n, k/n); "
                "stake-weighted without replacement: hypergeometric",
        "E_seats": "k",
        "Var_binomial": "k(1-k/n)",
    }
    # hypergeometric vs binomial capture for n=100, k in [...]
    rows = []
    n = 100
    A = int(n / 3)  # 33 adversarial validators (< 1/3 of 100)
    for k in [16, 32, 64, 100, 128 + 1, 200, 300]:
        kb = min(k, n)
        rows.append({
            "n": n, "adversary": A, "k": kb,
            "hyper_P_capture": hyper_capture_prob(n, kb, A, 2 / 3),
            "binom_P_capture": committee_capture_prob(kb, A / n, 2 / 3),
        })
    out["hyper_vs_binomial"] = rows
    # minimal k for a target security under the exact binomial law
    targets = []
    for eps_bits in [40, 64, 80]:
        eps = 2.0 ** (-eps_bits)
        row = {"target_bits": eps_bits}
        for alpha in [1 / 3, 0.30, 0.25]:
            row[f"k_exact_alpha={alpha:.2f}"] = min_k_for_eps(alpha, eps)
            row[f"k_chernoff_alpha={alpha:.2f}"] = min_k_for_eps(alpha, eps, bound=True)
        targets.append(row)
    out["min_k"] = targets
    # grinding: expected parent-hash draws to capture s seats
    grind = []
    for n in [100, 1000]:
        for k in [64, 128]:
            for s in [int(2 * k / 3) + 1]:
                if s <= k <= n:
                    log_c = sum(__import__("math").log((n - i) / (k - i)) for i in range(s))
                    grind.append({"n": n, "k": k, "s_needed": s,
                                  "expected_draws": __import__("math").exp(log_c)})
    out["grinding"] = grind
    return out


if __name__ == "__main__":
    result = {
        "meta": {
            "consensus_q": "floor(2n/3)+1",
            "bridge_q": "ceil(2n/3)",
            "exact_min_threshold": "floor((n+Bmax)/2)+1 with Bmax=max{b: b<n/3}",
        },
        "unweighted": run_unweighted(9),
        "weighted": run_weighted_examples(),
        "capture": run_capture_table(),
        "vrf": run_vrf(),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result["unweighted"], indent=2))
    print("\nWEIGHTED:", json.dumps(result["weighted"], indent=2))
    print("\nCAPTURE:")
    for r in result["capture"]:
        print(r)
