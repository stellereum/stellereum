#!/usr/bin/env python3
"""Phase 5: two new pure-math results.

  A. GRINDING COST IS 1/P_capture, NOT C(n,s)/C(k,s).
     The code's `expected_draws_to_capture_seats` prices a CHOSEN s-subset.
     An adversary only needs ANY capturing committee, so the expected number
     of parent hashes is the reciprocal of the capture probability.  At
     n=100, k=64, alpha=1/3 this is ~3.05e7 (0.03 s at 1e9 hashes/s), not
     ~9.27e11.  Grover: ~5.5e3 hashes.

  B. STRUCTURAL CAPTURE.
     With k seats and threshold q:
       * n_A < q                => P_capture = 0   (too few adversary validators)
       * n_B < k - q + 1        => P_capture = 1   (too few honest validators)
     In between, an exact 2-class successive-sampling DP.  The binomial bound
     is NOT distribution-free: it can underestimate (e.g. n_A=80,n_B=20,k=64
     => capture is certain, while Bin(64,1/3) says 3.3e-8).
"""
import json
import math
import os
from math import comb

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "phase5.json")


def capture_binomial(k, alpha, q):
    return sum(comb(k, a) * alpha ** a * (1 - alpha) ** (k - a)
               for a in range(q, k + 1))


def specific_subset_draws(n, k, s):
    if s > k or s > n:
        return float("inf")
    return math.exp(sum(math.log((n - i) / (k - i)) for i in range(s)))


def grinding_table():
    rows = []
    for n in [100, 1000, 10000]:
        for k in [64, 128, 177]:
            if k > n:
                continue
            q = 2 * k // 3 + 1
            pcap = capture_binomial(k, 1 / 3, q)
            e_any = 1.0 / pcap
            e_specific = specific_subset_draws(n, k, q)
            rows.append({
                "n": n, "k": k, "q": q,
                "P_capture_binomial": pcap,
                "E_draws_ANY_majority": e_any,
                "E_draws_SPECIFIC_subset": e_specific,
                "overestimate_factor": e_specific / e_any,
                "classical_s_at_1e9": e_any / 1e9,
                "quantum_grover_s_at_1e9": math.sqrt(e_any) / 1e9,
            })
    return rows


# --------------------------------------------------------------------------
# Exact 2-class successive sampling (Plackett-Luce) DP
# --------------------------------------------------------------------------
def capture_dp(nA, nB, wA, wB, k, q):
    if q > nA:
        return 0.0
    if nB < k - q + 1:
        return 1.0
    dp = [[0.0] * (min(k, nB) + 1) for _ in range(min(k, nA) + 1)]
    dp[0][0] = 1.0
    for t in range(k):
        ndp = [[0.0] * (min(k, nB) + 1) for _ in range(min(k, nA) + 1)]
        for a in range(0, min(t, nA) + 1):
            for b in range(0, min(t - a, nB) + 1):
                p = dp[a][b]
                if p == 0.0:
                    continue
                remA = (nA - a) * wA
                remB = (nB - b) * wB
                tot = remA + remB
                if tot <= 0:
                    continue
                if a < nA:
                    ndp[a + 1][b] += p * remA / tot
                if b < nB:
                    ndp[a][b + 1] += p * remB / tot
        dp = ndp
    return sum(sum(dp[a]) for a in range(q, min(k, nA) + 1))


def structural_table():
    n, alpha = 100, 1 / 3
    rows = []
    for k in [32, 64, 105, 128, 177]:
        q = 2 * k // 3 + 1
        row = {
            "k": k, "q": q,
            "capture_zero_if_nA_lt": q,
            "capture_certain_if_nB_le": k - q,
            "min_honest_validators": k - q + 1,
        }
        for nA in [q, min(n, q + 10), min(n, int(n * 0.5)),
                   min(n, int(n * 0.67)), min(n, int(n * 0.8))]:
            nB = n - nA
            if nA < q or nB <= 0:
                row[f"nA={nA}"] = 0.0
                continue
            wA = alpha / nA
            wB = (1 - alpha) / nB
            row[f"nA={nA}"] = capture_dp(nA, nB, wA, wB, k, q)
        rows.append(row)
    return rows


def phase_diagram():
    n, k, alpha = 100, 64, 1 / 3
    q = 2 * k // 3 + 1
    rows = []
    for nA in range(40, 86):
        nB = n - nA
        wA = alpha / nA
        wB = (1 - alpha) / nB
        rows.append({"nA": nA, "nB": nB, "P": capture_dp(nA, nB, wA, wB, k, q)})
    return {"k": k, "q": q, "rows": rows}


def run():
    return {
        "grinding": grinding_table(),
        "structural": structural_table(),
        "phase_diagram": phase_diagram(),
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
