#!/usr/bin/env python3
"""Parallel execution: wave decomposition of a block's transaction graph.

Model: each transaction touches d resource keys drawn uniformly from K.
Two transactions conflict iff their key sets intersect, with probability
    p = 1 - C(K-d, d) / C(K, d)   ~  d^2/K  (d << K).
A block is a graph G(m, p); a "wave" is an independent set.  The executor's
greedy first-fit partition (in transaction order) uses W waves.
We measure E[W], compare with the degree bound W <= Delta+1, and derive the
throughput-optimal batch size for P workers.
"""
import json
import math
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "waves.json")
random.seed(20261105)


def conflict_prob(K, d):
    if K - d < d:
        return 1.0
    return 1.0 - math.comb(K - d, d) / math.comb(K, d)


def one_block(m, K, d, rng):
    keys = [set(rng.sample(range(K), d)) for _ in range(m)]
    waves = []
    wave_ids = [0] * m
    for i in range(m):
        used = set()
        for j in range(i):
            if wave_ids[j] in used:
                continue
            if keys[i] & keys[j]:
                used.add(wave_ids[j])
        w = 0
        while w in used:
            w += 1
        wave_ids[i] = w
        waves.append(w)
    W = (max(waves) + 1) if waves else 0
    deg = [0] * m
    for i in range(m):
        for j in range(i + 1, m):
            if keys[i] & keys[j]:
                deg[i] += 1
                deg[j] += 1
    Delta = max(deg) if deg else 0
    return W, Delta


def run():
    out = {}
    K, d = 2000, 4
    p = conflict_prob(K, d)
    out["params"] = {"K": K, "d": d, "p_conflict": p}
    rows = []
    rng = random.Random(7)
    for m in [10, 25, 50, 100, 200, 400, 800, 1600]:
        trials = 120 if m <= 400 else 40
        Ws, Ds = [], []
        for _ in range(trials):
            W, D = one_block(m, K, d, rng)
            Ws.append(W)
            Ds.append(D)
        EW = sum(Ws) / len(Ws)
        ED = sum(Ds) / len(Ds)
        lam = (m - 1) * p
        rows.append({
            "m": m,
            "E_waves": round(EW, 2),
            "E_max_degree": round(ED, 1),
            "degree_bound_Delta_plus_1": ED + 1,
            "mean_degree_lambda": round(lam, 2),
            "speedup_vs_serial": round(m / EW, 2),
            "parallel_efficiency_at_P8": round(m / (EW * 8), 3),
        })
    out["scaling"] = rows

    # Fit E[W] ~ c m^b (sublinear) from the simulation.
    xs = [r["m"] for r in rows]
    ys = [r["E_waves"] for r in rows]
    b = (math.log(ys[-1]) - math.log(ys[0])) / (math.log(xs[-1]) - math.log(xs[0]))
    c = ys[0] / xs[0] ** b
    out["wave_law_fit"] = {"c": round(c, 4), "b": round(b, 4),
                           "law": "E[W] ~ c * m^b"}

    # Saturation: the batch size at which E[W] ~ P, i.e. P workers are just
    # saturated.  m*(P) = (P/c)^(1/b).  Beyond it, throughput approaches the
    # bandwidth limit (the wave overhead is amortised).
    sat = []
    for P in [2, 4, 8, 16, 32]:
        m_sat = (P / c) ** (1.0 / b)
        sat.append({"P": P, "m_star": int(round(m_sat)),
                    "E_waves_at_m_star": round(c * m_sat ** b, 2),
                    "speedup": round(P, 2)})
    out["saturation"] = sat
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
