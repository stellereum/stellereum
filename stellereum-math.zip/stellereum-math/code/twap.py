#!/usr/bin/env python3
"""Oracle: optimal TWAP/VWAP window and circuit-breaker thresholds.

Model (geometric/arithmetic price, explicitly stated):
  P(t) = P(0) + mu t + sigma W_t          (arithmetic Brownian motion)
  Window average over [t-W, t]:
      bias   = -mu W/2
      var    = sigma^2 W / 3
  Last-block manipulation: an attacker moves the final price by J for one
  block of length dt, contributing J*dt/W to the window average.  With
  sustained manipulation of size J for the whole window the contribution is J
  (the window cannot dilute it; the defence is the *cost* of sustaining it).
  MSE(W) = sigma^2 W/3 + (J dt / W)^2  ->  W* = (6 (J dt)^2 / sigma^2)^(1/3).

Circuit breaker (Gaussian deviations):
  false positive  alpha = 2 Phi(-theta/sigma)
  detection power 1-beta = Phi((J-theta)/sigma) + Phi((-J-theta)/sigma)
  => theta = sigma Phi^{-1}(1-alpha/2).
CUSUM/SPRT is the sequential alternative; we give Wald's approximation.
"""
import json
import math
import os
from statistics import NormalDist

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "twap.json")
ND = NormalDist()


def optimal_window(sigma_sec, J, dt):
    return (6.0 * (J * dt) ** 2 / sigma_sec ** 2) ** (1.0 / 3.0)


def mse(W, sigma_sec, J, dt):
    return sigma_sec ** 2 * W / 3.0 + (J * dt / W) ** 2


def breaker(sigma, alpha):
    return sigma * ND.inv_cdf(1 - alpha / 2)


def power(J, theta, sigma):
    return ND.cdf((J - theta) / sigma) + ND.cdf((-J - theta) / sigma)


def run():
    out = {}
    # 1) optimal window, 0.6s blocks, daily vol 2/5/10 %
    rows = []
    for vol_daily in [0.02, 0.05, 0.10]:
        sigma_sec = vol_daily / math.sqrt(86_400)
        for J in [0.02, 0.05, 0.10]:
            for dt in [0.6, 1.0]:
                W = optimal_window(sigma_sec, J, dt)
                rows.append({
                    "vol_daily": vol_daily, "block_s": dt,
                    "manipulation_J": J,
                    "W_star_s": round(W, 1),
                    "W_star_blocks": round(W / dt, 1),
                    "mse_at_W_star": mse(W, sigma_sec, J, dt),
                    "mse_at_3600s": mse(3600, sigma_sec, J, dt),
                    "mse_at_60s": mse(60, sigma_sec, J, dt),
                })
    out["optimal_window"] = rows

    # 2) circuit breaker table
    cb = []
    for sigma in [0.0025, 0.005, 0.01, 0.02]:  # per-block relative sigma
        for alpha in [1e-2, 1e-3, 1e-4, 1e-6]:
            theta = breaker(sigma, alpha)
            row = {
                "sigma_per_block": sigma, "alpha": alpha,
                "theta_pct": round(100 * theta, 3),
            }
            for J in [0.02, 0.05, 0.10]:
                row[f"power_J={J}"] = round(power(J, theta, sigma), 6)
            cb.append(row)
    out["circuit_breaker"] = cb

    # 3) Wald SPRT for a mean shift 0 -> J, variance sigma^2 per observation.
    #    log-likelihood ratio per sample = (J/sigma^2) x - J^2/(2 sigma^2).
    #    Thresholds A=ln((1-beta)/alpha), B=ln(beta/(1-alpha)).
    #    Expected sample size  E[N] ~ (A + B) / (J^2/(2 sigma^2))  (drift).
    sprt = []
    for J in [0.01, 0.02, 0.05]:
        for sigma in [0.005, 0.01]:
            for alpha, beta in [(1e-3, 1e-3), (1e-4, 1e-4)]:
                A = math.log((1 - beta) / alpha)
                B = math.log(beta / (1 - alpha))
                drift = J * J / (2 * sigma * sigma)
                # Wald identity: E[N | H1] * drift = (1-beta) A + beta B
                e_n = ((1 - beta) * A + beta * B) / drift
                sprt.append({
                    "J": J, "sigma": sigma, "alpha": alpha, "beta": beta,
                    "drift_per_sample": drift,
                    "expected_samples_to_decide": round(e_n, 2),
                })
    out["sprt"] = sprt
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
