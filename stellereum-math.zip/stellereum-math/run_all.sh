#!/usr/bin/env bash
# Reproduce every result in this folder.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results
for f in q_quorum liveness pmm emission twap waves xshard mmr falcon pq_theorems; do
  echo "=== $f ==="
  python3 "code/$f.py" >/dev/null
  echo "  -> results/$f.json"
done
echo "=== verify ==="
python3 code/verify_claims.py
echo "done."
