#!/usr/bin/env python3
"""Phase-2: new post-quantum theorems for Stellereum.

Computes the quantitative side of four new results:

  A. VUF/VRF: a non-unique signature scheme is grindable (Falcon!), a unique
     one is a VRF (XMSS epoch construction).  Grinding amplification table.
  B. Threshold MEV decryption with f Byzantine and d dropouts:
     feasibility n >= 2f + d + 1, optimal t* = floor((n-d)/2)+1, liveness tail.
  C. QC compression: succinct proof vs raw Falcon, exact crossover.
  D. Quantum hash security: Grover (preimage n/2) and BHT (collision n/3),
     composite chain security min(signature, hash).
"""
import json
import math
import os
from math import comb

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "pq_theorems.json")


# --------------------------------------------------------------------------
# A. VUF grinding
# --------------------------------------------------------------------------
def grind_prob(p, Q):
    """P[at least one of Q valid signatures lands in the election interval]."""
    return 1.0 - (1.0 - p) ** Q


def grinding_table():
    rows = []
    k = 64
    for stake in [0.001, 0.005, 0.01, 0.05, 0.10, 1 / 3]:
        p = stake * k  # ticket prob per signature (approx)
        p = min(p, 1.0)
        row = {"stake_fraction": stake, "p_one_signature": p}
        for qbits in [0, 4, 10, 20, 30]:
            Q = 1 << qbits
            row[f"P_Q=2^{qbits}"] = grind_prob(p, Q)
        # expected signatures to guarantee a seat
        row["Q_expected_for_one_seat"] = (1.0 / p) if p > 0 else float("inf")
        rows.append(row)
    return rows


# --------------------------------------------------------------------------
# B. Threshold MEV with f Byzantine + d dropouts
# --------------------------------------------------------------------------
def threshold_row(n, f, d):
    feasible = n >= 2 * f + d + 1
    if n - d < 1:
        return None
    t_star = (n - d) // 2 + 1
    if not feasible:
        return {
            "n": n, "f": f, "d": d, "feasible": False,
            "reason": "n < 2f + d + 1",
        }
    # clamp t* into the feasible interval [f+1, n-f-d]
    t_lo, t_hi = f + 1, n - f - d
    t = min(max(t_star, t_lo), t_hi)
    return {
        "n": n, "f": f, "d": d, "feasible": True,
        "t_range": [t_lo, t_hi],
        "t_star": t_star, "t_used": t,
        "secrecy_margin": t - f,
        "liveness_margin": n - f - d - t + 1,
        "n_min_for_feasibility": 2 * f + d + 1,
    }


def binomial_tail(n, p, threshold):
    """P[X < threshold] for X ~ Bin(n,p), exact."""
    if threshold <= 0:
        return 0.0
    if threshold > n:
        return 1.0
    return sum(comb(n, x) * p ** x * (1 - p) ** (n - x)
               for x in range(0, threshold))


def threshold_tables():
    out = {"feasibility": [], "liveness": []}
    for n in [4, 10, 50, 100, 200, 300]:
        f = (n - 1) // 3
        for d in [0, 1, 2, 5, 10]:
            r = threshold_row(n, f, d)
            if r:
                out["feasibility"].append(r)
    # liveness failure for a concrete committee
    n, f, d = 100, 33, 5
    t = threshold_row(n, f, d)["t_used"]
    for q in [0.01, 0.05, 0.10, 0.20]:
        online = n - f
        out["liveness"].append({
            "n": n, "f": f, "d_assumed": d, "t": t,
            "offline_prob": q,
            "P[online < t]": binomial_tail(online, 1 - q, t),
        })
    return out


# --------------------------------------------------------------------------
# C. QC compression
# --------------------------------------------------------------------------
def qc_table(stark_kb_values=(50, 100, 200, 500), k_values=(16, 64, 105, 128, 177, 256, 512)):
    rows = []
    for k in k_values:
        raw = 666 * k + k // 8
        row = {"k": k, "raw_bytes": raw}
        for s in stark_kb_values:
            snark = s * 1024 + 32 + k // 8
            row[f"stark_{s}kb_bytes"] = snark
            row[f"stark_{s}kb_wins"] = snark < raw
        rows.append(row)
    cross = []
    for s in stark_kb_values:
        cross.append({"stark_kb": s,
                      "crossover_k": round((s * 1024 + 32) / 666, 1)})
    return {"rows": rows, "crossover": cross}


# --------------------------------------------------------------------------
# D. Quantum hash security + composite chain security
# --------------------------------------------------------------------------
def hash_security():
    rows = []
    for bits in [256, 384, 512]:
        rows.append({
            "hash_bits": bits,
            "classical_collision": bits / 2,
            "quantum_preimage_grover": bits / 2,
            "quantum_collision_bht": bits / 3,
        })
    return rows


def composite_security(falcon_bits, hash_bits):
    return min(falcon_bits, hash_bits / 3, hash_bits / 2)


def composite_table():
    rows = []
    for name, sig in [("Falcon-512", 110.2), ("Falcon-1024", 253.3)]:
        for hb in [256, 384, 512, 768]:
            rows.append({
                "signature": name, "signature_bits": sig,
                "hash_bits": hb,
                "quantum_collision_bits": hb / 3,
                "composite_bits": round(composite_security(sig, hb), 1),
            })
    return rows


def run():
    return {
        "grinding": grinding_table(),
        "threshold": threshold_tables(),
        "qc": qc_table(),
        "hash": hash_security(),
        "composite": composite_table(),
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
