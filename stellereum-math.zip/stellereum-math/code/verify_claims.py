#!/usr/bin/env python3
"""Assert the headline claims against the generated JSON.  Exits non-zero if
any claim fails, so `run_all.sh && verify_claims.py` is a CI-style check."""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
R = os.path.join(HERE, "..", "results")


def load(name):
    with open(os.path.join(R, name)) as f:
        return json.load(f)


checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


# PMM: sign error
pmm = load("pmm.json")
rt = {r["buy_usd"]: r for r in pmm["round_trip"]}
check("PMM 100M loss > 90%", rt[100_000_000]["code_loss_pct"] > 90,
      f"{rt[100_000_000]['code_loss_pct']:.2f}%")
check("PMM 250M pays 0", rt[250_000_000]["sell_code_usd"] == 0)
check("PMM correct round-trip loss ~ 0",
      abs(rt[10_000]["correct_loss_pct"]) < 1e-6)
check("PMM f_max(1,0.2) ~ 0.735",
      abs(pmm["max_redeemable_fraction"][2]["f_max_at_s=1.0Sc"] - 0.7351) < 1e-3)

# Quorum
q = load("q_quorum.json")
w = q["weighted"]
check("µQC t=51 unsafe", w["threshold_table"][0]["safe"] is False)
check("µQC t=67 safe", w["threshold_table"][1]["safe"] is True)
check("cross-tier unsafe", w["threshold_table"][2]["cross_tier"]["safe"] is False)
check("attack both certs valid", w["explicit_attack"]["both_certs_valid"] is True)
check("attack intersection all byzantine",
      w["explicit_attack"]["intersection_is_all_byzantine"] is True)
cap = {r["k"]: r for r in q["capture"]["by_size"]}
check("k=64 capture ≈ 3.28e-8",
      abs(cap[64]["alpha=1/3,P[>=2/3]"] - 3.276869180935257e-08) < 1e-15)

# Liveness
lv = load("liveness.json")
row = [r for r in lv["by_gamma"] if r["gamma"] == 2.0][0]
c500 = [c for c in row["cases"] if c["c_ms"] == 500][0]
check("T*(c=500) ≈ 2789", abs(c500["T_star_ms"] - 2788.9) < 1.0,
      f"{c500['T_star_ms']}")
check("current ladder within 1% of optimum",
      abs(c500["speedup_vs_ladder"] - 1.0) < 0.01)
check("iid rho* = 1", lv["iid_geometric_opt"]["rho"] == 1.0)
check("persistent rho* > 1.5", lv["persistent_model"]["rho_star"] > 1.5)

# Emission
em = load("emission.json")
ex = {r["block_time_s"]: r for r in em["exhaustion_by_block_time"]}
check("0.6s exhaust ≈ 21y", abs(ex[0.6]["exhaust_years"] - 21.006) < 0.01)
check("0.2s exhaust ≈ 7y", abs(ex[0.2]["exhaust_years"] - 7.002) < 0.01)

# Oracle
tw = load("twap.json")
w50 = [r for r in tw["optimal_window"]
       if r["vol_daily"] == 0.05 and r["block_s"] == 0.6 and r["manipulation_J"] == 0.1][0]
check("W* ≈ 90.7s", abs(w50["W_star_s"] - 90.7) < 0.2, f"{w50['W_star_s']}")
check("MSE at W* << MSE at 3600", w50["mse_at_W_star"] * 20 < w50["mse_at_3600s"])

# Waves
wv = load("waves.json")
check("E[W] fit b ≈ 0.41", abs(wv["wave_law_fit"]["b"] - 0.4097) < 0.01)
sat8 = [r for r in wv["saturation"] if r["P"] == 8][0]
check("P=8 saturation ~ 704", abs(sat8["m_star"] - 704) <= 2, f"{sat8['m_star']}")

# 2PC
xs = load("xshard.json")
check("2PC I1 holds", xs["two_pc"]["I1_holds"] is True)
check("2PC I3 holds", xs["two_pc"]["I3_holds"] is True)
check("old protocol mints value", xs["old_protocol"]["value_minted"] is True)

# MMR
mm = load("mmr.json")
check("MMR all n=1..512 verified", mm["all_1_to_512_verified"] is True)
check("MMR tamper rejected", mm["tamper"]["tampered_proof_rejected"] is True)
check("MMR valid proof accepted", mm["tamper"]["valid_proof_verifies"] is True)

# Falcon
fal = load("falcon.json")
f512 = fal["lattices"][0]
check("Falcon-512 BKZ 416", f512["bkz_block_size"] == 416)
check("Falcon-512 classical bits 121.5", abs(f512["core_svp_classical_bits"] - 121.5) < 0.1)

# Phase-2 PQ theorems
pq = load("pq_theorems.json")
g = {r["stake_fraction"]: r for r in pq["grinding"]}
check("grinding 0.1% Q=16 ~ 0.653",
      abs(g[0.001]["P_Q=2^4"] - 0.6529327938326646) < 1e-12)
check("grinding 0.1% needs ~16 signatures",
      abs(g[0.001]["Q_expected_for_one_seat"] - 15.625) < 1e-9)
th = [r for r in pq["threshold"]["feasibility"]
      if r["n"] == 100 and r["d"] == 5][0]
check("threshold t*=48 for n=100,d=5", th["t_used"] == 48)
check("threshold margins balanced",
      th["secrecy_margin"] == 15 and th["liveness_margin"] == 15)
lv = [r for r in pq["threshold"]["liveness"] if r["offline_prob"] == 0.1][0]
check("liveness q=10% ~ 5.4e-6",
      abs(lv["P[online < t]"] - 5.4180090773016965e-06) < 1e-12)
cross = {r["stark_kb"]: r for r in pq["qc"]["crossover"]}
check("QC crossover 100KB ~ 153.8", abs(cross[100]["crossover_k"] - 153.8) < 0.1)
h = {r["hash_bits"]: r for r in pq["hash"]}
check("256-bit hash collision PQ = 85.33",
      abs(h[256]["quantum_collision_bht"] - 85.33333333333333) < 1e-9)
comp = {(r["signature"], r["hash_bits"]): r for r in pq["composite"]}
check("composite Falcon-512+256 = 85.3",
      abs(comp[("Falcon-512", 256)]["composite_bits"] - 85.3) < 0.1)
check("composite Falcon-1024+384 = 128",
      abs(comp[("Falcon-1024", 384)]["composite_bits"] - 128.0) < 0.1)

# Phase-3 PQ theorems
p3 = load("pq_phase3.json")
fr = {r["delta_bits"]: r for r in p3["sampling"]["fraction_table"]}
check("sampling eps=1/3, delta=2^-40 needs 69",
      fr[40]["eps=0.333"] == 69)
one = {r["k"]: r for r in p3["sampling"]["one_bad"]}
check("one bad needs s=k at delta=2^-40",
      one[256]["s_needed_one_bad_delta_2^-40"] == 256)
bond = {(r["k"], r["s"]): r for r in p3["sampling"]["bond"]}
check("bond B/V=1 for k=64,s=32",
      abs(bond[(64, 32)]["bond_over_value"] - 1.0) < 1e-9)
life = {(r["t"], r["f_per_epoch"]): r for r in p3["proactive"]["lifetime_without_refresh"]}
check("static lifetime t=34,f=1 is 33 epochs",
      life[(34, 1)]["T_epochs_secrecy"] == 33)
ref = [r for r in p3["proactive"]["refresh_interval"]
       if r["n"] == 100 and r["lambda_per_epoch"] == 0.01 and r["delta_bits"] == 40][0]
check("proactive Delta* ~ 8.54", abs(ref["Delta_star"] - 8.54) < 0.01)
check("proactive P[fail] ~ 9.1e-13",
      abs(ref["P[fail]"] - 9.094947017729245e-13) < 1e-18)
mt = {(r["hash_bits"], r["log2_targets"]): r for r in p3["multi_target"]}
check("multi-target 256/2^20 = 65.33 bits",
      abs(mt[(256, 20)]["collision_bits"] - 65.33333333333333) < 1e-9)
ge = {r["p_one_signature"]: r for r in p3["grinding_economics"]}
check("grinding slashing S>0.999R for p=0.001",
      abs(ge[0.001]["min_slashing_over_reward"] - 0.999) < 1e-12)
agg = {r["k"]: r for r in p3["aggregation"]}
check("aggregation k=64 norm factor 8, loss 3 bits",
      agg[64]["random_norm_factor"] == 8.0 and
      abs(agg[64]["security_loss_bits_random"] - 3.0) < 1e-9)

# Phase-4: red-team + new proofs
p4 = load("phase4.json")
check("integer PMM invariant R>=V(S)", p4["pmm"]["ok"] is True)
check("integer PMM min slack >= 0", p4["pmm"]["min_slack_micro_usd"] >= 0)
check("integer PMM round-trip loss == 0",
      p4["pmm"]["worst_roundtrip_loss_micro_usd"] == 0)
fp = {r["scenario"]: r for r in p4["fraud_proof"]["rows"]}
check("fraud proof: unpredictable challenge detects",
      abs(fp["unpredictable challenge (uniform sample)"]["P_det"] - 0.653072285207994) < 1e-12)
check("fraud proof: predictable challenge fails",
      fp["predictable challenge (adversary picks positions)"]["P_det"] == 0.0)
pu = {r["intervals_T"]: r for r in p4["proactive_union"]["rows"]}
check("proactive union T=1e6 Delta* ~1.067",
      abs(pu[10**6]["Delta_star"] - 1.067) < 0.01)
xv = {(r["hash_bits"], r["queries"]): r for r in p4["xmss_vrf"]["rows"]}
check("XMSS-VRF kappa=128,q=2^30 ROM term = 98 bits",
      abs(xv[(128, "2^30")]["rom_guess_term_bits"] - 98.0) < 1e-9)

# Phase-5: grinding + structural capture
p5 = load("phase5.json")
g64 = [r for r in p5["grinding"] if r["n"] == 100 and r["k"] == 64][0]
check("grinding any-majority ~3.05e7",
      abs(g64["E_draws_ANY_majority"] - 30516933.84093497) < 1.0)
check("grinding specific ~9.27e11",
      abs(g64["E_draws_SPECIFIC_subset"] - 927229147388.719) < 1.0)
check("grinding overestimate ~30384x",
      abs(g64["overestimate_factor"] - 30384.086167429683) < 1.0)
check("quantum grinding ~5524 hashes",
      abs(math.sqrt(g64["E_draws_ANY_majority"]) - 5524.21) < 0.1)
st = {r["k"]: r for r in p5["structural"]}
check("structural k=64 min honest = 22", st[64]["min_honest_validators"] == 22)
check("structural k=64 capture certain if nB<=21",
      st[64]["capture_certain_if_nB_le"] == 21)
check("structural nA=80 capture = 1.0", st[64]["nA=80"] == 1.0)
check("structural nA=43 capture tiny", st[64]["nA=43"] < 1e-15)
check("phase nA=78 capture ~0.103",
      abs([r for r in p5["phase_diagram"]["rows"] if r["nA"] == 78][0]["P"] - 0.10279640853230351) < 1e-12)

# Phase-6: XMSS-VRF prototype + 2PC refinement
xv = load("xmss_vrf.json")
check("XMSS-VRF correctness", xv["summary"]["correctness"] is True)
check("XMSS-VRF unique signature", xv["summary"]["unique_signature"] is True)
check("XMSS-VRF rejections", xv["summary"]["rejections_ok"] is True)
check("XMSS-VRF toy forgery verifies", xv["summary"]["toy_forgery_verifies"] is True)
check("XMSS-VRF signature 2336 bytes", xv["summary"]["signature_bytes"] == 2336)
xr = load("xpc_refinement.json")
check("2PC abstract states = 9", len(xr["abstract_states"]) == 9)
check("2PC proof-only apply credits forged leaf",
      xr["attack"]["apply_proof_only"]["accepted"] is True and
      xr["attack"]["apply_proof_only"]["credited"] is True)
check("2PC anchored apply rejects forged leaf",
      xr["attack"]["apply_anchored"]["accepted"] is False)
check("2PC gap documented", "R5" in " ".join(xr["refinement_obligations"]))

# Phase-7: full refinement + stateful XMSS
xrf = load("xpc_refinement_full.json")
check("refinement anchored safe",
      xrf["anchored"]["safe"] is True and xrf["anchored"]["violation_count"] == 0)
check("refinement proof-only unsafe",
      xrf["proof_only"]["safe"] is False)
check("refinement counterexample is a mint",
      xrf["counterexample"]["kind"] == "mint without source")
check("refinement reachable abstract = 9", len(xrf["abstract_states"]) == 9)
xs = load("xmss_vrf_stateful.json")
check("stateful XMSS first sign", xs["stateful"]["first_sign_ok"] is True)
check("stateful XMSS refuses leaf reuse",
      xs["stateful"]["second_sign_same_leaf_refused"] is True)
check("stateful XMSS next leaf", xs["stateful"]["next_leaf_ok"] is True)
check("stateful XMSS wrong epoch rejected",
      xs["stateful"]["wrong_epoch_rejected"] is True)
h10 = [b for b in xs["benchmark"] if b["height"] == 10][0]
check("stateful XMSS h=10 sig = 2464", h10["signature_bytes"] == 2464)

ok = True
for name, passed, detail in checks:
    mark = "PASS" if passed else "FAIL"
    print(f"[{mark}] {name}" + (f"  ({detail})" if detail else ""))
    ok = ok and passed
print(f"\n{sum(1 for _, p, _ in checks if p)}/{len(checks)} claims verified")
sys.exit(0 if ok else 1)
