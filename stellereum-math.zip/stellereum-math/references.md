# Источники и стандарты

Ниже — работы и стандарты, на которых стоят формулировки. Ссылки даны
названиями (без вымышленных URL).

## Консенсус и BFT

* M. Castro, B. Liskov. *Practical Byzantine Fault Tolerance*. OSDI 1999.
* E. Buchman, J. Kwon, Z. Milosevic. *The latest gossip on BFT consensus*
  (Tendermint). 2018.
* L. Lamport, R. Shostak, M. Pease. *The Byzantine Generals Problem*. 1982.
* R. Pass, E. Shi. *Thunderella / Hybrid consensus*. 2017 (для границ
  синхронности/асинхронности).
* D. M. Topkis. *Supermodularity and Complementarity*. 1998
  (монотонная сравнительная статика для таймаутов).

## Пост-квантовая криптография

* NIST FIPS 203 (ML-KEM), FIPS 204 (ML-DSA), FIPS 206 (Falcon, draft).
* P.-A. Fouque, J. Hoffstein, P. Kirchner, V. Lyubashevsky, T. Pornin,
  T. Prest, T. Ricosset, G. Seiler, W. Whyte, Z. Zhang. *Falcon: Fast-Fourier
  Lattice-based Compact Signatures over NTRU*. NIST PQC submission, 2020.
* A. Alkim, L. Ducas, T. Pöppelmann, P. Schwabe. *Post-quantum key exchange —
  a new hope*. USENIX Security 2016 (core-SVP методология).
* A. Becker, L. Ducas, N. Gama, T. Laarhoven. *New directions in nearest
  neighbor searching with applications to lattice sieving*. SODA 2016
  (коэффициенты 0.292 / 0.265).
* RFC 9381. *Verifiable Random Functions (VRFs)* (ECVRF).
* M. Beullens, et al. *LaBRADOR: Compact Proofs for R1CS from Module-SIS*.
  CRYPTO 2023 (лэттис-SNARK, ориентир по размеру).
* E. Ben-Sasson, I. Bentov, Y. Horesh, M. Riabzev. *Scalable, transparent,
  and post-quantum secure computational integrity*. 2018 (STARK).
* A. Shamir. *How to share a secret*. 1979.

## Экономика и AMM

* J. Milionis, C. C. Moallemi, T. Roughgarden, A. L. Zhang.
  *Automated Market Making and Loss-Versus-Rebalancing*. 2022.
* G. Angeris, T. Chitra, A. Evans, S. Kulkarni. *A Primer on Perpetuals /
  AMM formulas*. 2021–2022 (интегралы кривых).
* F. A. Hayek / рыночные механизмы — вне формальной части.

## Статистика и последовательный анализ

* A. Wald. *Sequential Analysis*. 1947 (SPRT, тождество Вальда).
* H. Chernoff. *A measure of asymptotic efficiency for tests of a hypothesis
  based on the sum of observations*. 1952.
* I. N. Sanov. *On the probability of large deviations of random variables*.
  1957.
* E. L. Lehmann, J. P. Romano. *Testing Statistical Hypotheses*. 2005.

## Случайные графы и планирование

* P. Erdős, A. Rényi. *On the evolution of random graphs*. 1960.
* B. Bollobás. *Random Graphs*. 2001 (степени, хроматическое число).
* M. Mitzenmacher, E. Upfal. *Probability and Computing*. 2005.

## Структуры данных

* R. C. Merkle. *A certified digital signature*. CRYPTO 1989.
* S. Crosby, D. Wallach. *Efficient data structures for tamper-evident
  logging*. USENIX Security 2009 (history trees).
* Merkle Mountain Ranges (MMR): конструкция, используемая в
  Grin/MimbleWimble; в коде — `src/mmr.rs`.

## Код

* `stellereum/stellereum` (GitHub), ветка `main`, коммит на 2026-11-05.
  Файлы и строки указаны в тексте статей.
