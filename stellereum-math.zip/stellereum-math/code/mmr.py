#!/usr/bin/env python3
"""Merkle Mountain Range (MMR): peaks, inclusion proofs, and the popcount law.

Theorem (peak decomposition).  The MMR over n leaves is the forest of perfect
binary trees given by the binary expansion n = sum_{j in S} 2^j.  Hence
    #peaks(n) = popcount(n)
and the peak heights are exactly the positions of the 1-bits.
An inclusion proof for leaf i consists of the sibling path inside its perfect
subtree (h hashes) plus the roots of the other peaks (popcount(n)-1 hashes):
    |proof| = h + popcount(n) - 1 <= floor(log2 n) + popcount(n) - 1.
For n = 2^k - 1 the MMR is one perfect tree and |proof| = k.

This module builds an actual MMR over arbitrary leaves, emits and verifies
inclusion proofs, and checks the law exhaustively for small n.
"""
import hashlib
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "mmr.json")


def H(*parts):
    h = hashlib.sha256()
    for p in parts:
        if isinstance(p, str):
            p = p.encode()
        h.update(p)
    return h.digest()


def leaf_hash(x):
    return H(b"\x00", x)


def node_hash(l, r):
    return H(b"\x01", l, r)


def bag(peaks):
    """Canonical root: fold the peaks right-to-left with a domain tag."""
    if not peaks:
        return H(b"\x02")
    acc = peaks[-1]
    for p in reversed(peaks[:-1]):
        acc = H(b"\x03", p, acc)
    return acc


def peak_sizes(n):
    """Perfect subtree sizes (powers of two) from largest to smallest."""
    out = []
    j = n.bit_length() - 1
    while j >= 0:
        if (n >> j) & 1:
            out.append(1 << j)
        j -= 1
    return out


def build_subtree(leaves, start, size):
    """Root of the perfect subtree over leaves[start:start+size]."""
    if size == 1:
        return leaf_hash(leaves[start])
    half = size // 2
    return node_hash(build_subtree(leaves, start, half),
                     build_subtree(leaves, start + half, half))


def inclusion_proof(leaves, index):
    n = len(leaves)
    sizes = peak_sizes(n)
    pos = 0
    for si, size in enumerate(sizes):
        if index < pos + size:
            # sibling path inside this perfect subtree
            path = []

            def rec(start, sz, idx):
                if sz == 1:
                    return leaf_hash(leaves[start])
                half = sz // 2
                if idx < half:
                    sib = build_subtree(leaves, start + half, half)
                    path.append(("R", sib))
                    return node_hash(rec(start, half, idx), sib)
                else:
                    sib = build_subtree(leaves, start, half)
                    path.append(("L", sib))
                    return node_hash(sib, rec(start + half, half, idx - half))
            sub_root = rec(pos, size, index - pos)
            path.reverse()  # rec appends root->leaf; proofs are leaf->root
            other = [build_subtree(leaves, s, sz) for s, sz in
                     peak_iter(sizes) if s != pos]
            # preserve left-to-right order of the other peaks
            others_ordered = []
            q = 0
            for sz2 in sizes:
                if q != pos:
                    others_ordered.append(build_subtree(leaves, q, sz2))
                q += sz2
            return {
                "index": index, "size": size, "offset": pos,
                "path": path, "sub_root": sub_root,
                "other_peaks": others_ordered,
                "proof_len": len(path) + len(others_ordered),
            }
        pos += size
    raise IndexError


def peak_iter(sizes):
    pos = 0
    for sz in sizes:
        yield pos, sz
        pos += sz


def verify_proof(leaves, index, proof, root):
    acc = leaf_hash(leaves[index])
    for side, sib in proof["path"]:
        acc = node_hash(acc, sib) if side == "R" else node_hash(sib, acc)
    if acc != proof["sub_root"]:
        return False
    # rebuild the peak list with this peak replaced by the recomputed root
    sizes = peak_sizes(len(leaves))
    peaks = []
    oi = 0
    for sz in sizes:
        if sz == proof["size"]:
            peaks.append(acc)
        else:
            peaks.append(proof["other_peaks"][oi])
            oi += 1
    return bag(peaks) == root


def run():
    out = {}
    # 1) popcount law + proof length, exhaustive n = 1..512
    law = []
    ok = True
    max_proof = 0
    for n in range(1, 513):
        leaves = [f"tx{i}".encode() for i in range(n)]
        sizes = peak_sizes(n)
        if len(sizes) != bin(n).count("1"):
            ok = False
        peaks = [build_subtree(leaves, s, sz) for s, sz in peak_iter(sizes)]
        root = bag(peaks)
        idx = n // 3
        proof = inclusion_proof(leaves, idx)
        if not verify_proof(leaves, idx, proof, root):
            ok = False
        max_proof = max(max_proof, proof["proof_len"])
        if n in [1, 2, 3, 4, 5, 7, 8, 15, 16, 31, 32, 100, 256, 511, 512]:
            law.append({
                "n": n, "popcount": bin(n).count("1"),
                "peak_sizes": sizes, "proof_len": proof["proof_len"],
                "log2_floor": n.bit_length() - 1,
                "bound": n.bit_length() - 1 + bin(n).count("1") - 1,
            })
    out["law"] = law
    out["all_1_to_512_verified"] = ok
    out["max_proof_len_in_range"] = max_proof

    # 2) tamper detection
    n = 100
    leaves = [f"tx{i}".encode() for i in range(n)]
    sizes = peak_sizes(n)
    peaks = [build_subtree(leaves, s, sz) for s, sz in peak_iter(sizes)]
    root = bag(peaks)
    proof = inclusion_proof(leaves, 42)
    bad = dict(proof)
    bad["path"] = list(proof["path"])
    if bad["path"]:
        bad["path"][0] = (bad["path"][0][0], b"\x00" * 32)
    out["tamper"] = {
        "valid_proof_verifies": verify_proof(leaves, 42, proof, root),
        "tampered_proof_rejected": not verify_proof(leaves, 42, bad, root),
    }
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
