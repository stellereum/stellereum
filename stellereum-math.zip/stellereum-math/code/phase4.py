#!/usr/bin/env python3
"""Phase 4: red-team checks + new proofs.

  1. Integer-exact PMM solvency (the earlier P3 theorem assumed exact reals;
     the code floors).  Simulate the ACTUAL integer formulas and check the
     invariant R >= V(S) and the round-trip slack.
  2. Fraud-proof QC: why the sampling challenge must be unpredictable.
  3. Proactive threshold: union bound over T intervals (P11 stated a
     per-interval guarantee; correct it).
  4. XMSS-VRF: the ROM advantage bound  q_H/2^k + Adv_EUF.
"""
import json
import math
import os
import random
from math import comb

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "phase4.json")
random.seed(20261105)

P0 = 250_000
SC = 125_000_000 * 10**9
NANO = 10**9


# --------------------------------------------------------------------------
# 1. Integer-exact PMM
# --------------------------------------------------------------------------
def isqrt(n):
    if n == 0:
        return 0
    x = n
    y = (x + 1) // 2
    while y < x:
        x = y
        y = (x + n // x) // 2
    return x


def mint_for_usdt(s, u):
    k = u * NANO // P0
    a = s + SC
    disc = a * a + 2 * SC * k
    return isqrt(disc) - a


def buy_cost(s, d):
    return P0 * (d + ((s + d) ** 2 - s * s) // (2 * SC)) // NANO


def sell_correct(s, d):
    return P0 * (d + (s * s - (s - d) ** 2) // (2 * SC)) // NANO


def V_real(s):
    return P0 * (s + s * s / (2 * SC)) / NANO


def pmm_solvency():
    S, R = 0, 0
    min_slack = float("inf")
    max_slack = 0.0
    worst_rt = 0
    ops = 0
    for _ in range(20_000):
        if S == 0 or random.random() < 0.6:
            u = random.randint(1, 10_000_000)  # micro-USD
            d = mint_for_usdt(S, u)
            if d <= 0:
                continue
            cost = buy_cost(S, d)
            if cost > u:  # must never happen
                return {"ok": False, "reason": "buy cost > paid", "S": S, "u": u, "d": d}
            S2 = S + d
            R2 = R + u
            # round-trip check on a small d
            rt_d = max(1, d // 1000)
            rt_cost = buy_cost(S, rt_d)
            rt_sell = sell_correct(S + rt_d, rt_d)
            worst_rt = max(worst_rt, rt_cost - rt_sell)
            S, R = S2, R2
        else:
            d = random.randint(1, max(1, S // 10))
            if d > S:
                continue
            payout = sell_correct(S, d)
            if payout > R:
                return {"ok": False, "reason": "payout > reserve", "S": S, "R": R,
                        "d": d, "payout": payout}
            S, R = S - d, R - payout
        slack = R - V_real(S)
        min_slack = min(min_slack, slack)
        max_slack = max(max_slack, slack)
        ops += 1
    return {
        "ok": min_slack >= -1e-6,
        "ops": ops,
        "min_slack_micro_usd": min_slack,
        "max_slack_micro_usd": max_slack,
        "worst_roundtrip_loss_micro_usd": worst_rt,
        "invariant": "R >= V(S) with integer floors",
    }


# --------------------------------------------------------------------------
# 2. Fraud-proof QC: adaptive vs unpredictable challenge
# --------------------------------------------------------------------------
def detect_prob(k, e, s):
    if s >= k or k - e < s:
        return 1.0
    return 1.0 - comb(k - e, s) / comb(k, s)


def fraud_proof():
    k, e, s = 1000, 10, 100
    rows = []
    for label, p in [("unpredictable challenge (uniform sample)", detect_prob(k, e, s)),
                     ("predictable challenge (adversary picks positions)", 0.0)]:
        rows.append({"scenario": label, "P_det": p})
    return {
        "k": k, "bad": e, "sample": s,
        "rows": rows,
        "note": "the challenge must include an unpredictable beacon; a "
                "proposer-controlled block hash lets the adversary hide the "
                "bad signatures in the unsampled positions",
    }


# --------------------------------------------------------------------------
# 3. Proactive threshold: union bound over T intervals
# --------------------------------------------------------------------------
def binom_tail_ge(n, p, t):
    return sum(comb(n, x) * p ** x * (1 - p) ** (n - x) for x in range(t, n + 1))


def max_delta(n, t, lam, delta):
    lo, hi = 1e-12, 1e7
    for _ in range(200):
        mid = (lo + hi) / 2
        p = min(lam * mid, 1.0)
        if binom_tail_ge(n, p, t) <= delta:
            lo = mid
        else:
            hi = mid
    return lo


def proactive_union():
    n, t, lam = 100, 34, 0.05
    rows = []
    for T in [1, 10, 10**3, 10**6]:
        for total_bits in [40]:
            total = 2.0 ** (-total_bits)
            per = total / T
            d = max_delta(n, t, lam, per)
            rows.append({
                "intervals_T": T,
                "total_delta_bits": total_bits,
                "per_interval_delta_bits": math.log2(per),
                "Delta_star": d,
            })
    return {"n": n, "t": t, "lambda": lam, "rows": rows,
            "note": "P[any interval fails] <= T * delta; set per-interval "
                    "delta = delta_total / T"}


# --------------------------------------------------------------------------
# 4. XMSS-VRF ROM advantage bound
# --------------------------------------------------------------------------
def xmss_vrf_bound():
    rows = []
    for kappa in [128, 256]:
        for qh in [2**20, 2**30, 2**40]:
            rows.append({
                "hash_bits": kappa,
                "queries": f"2^{int(math.log2(qh))}",
                "rom_guess_term_bits": kappa - math.log2(qh),
            })
    return {"rows": rows,
            "bound": "Adv_unpred <= q_H / 2^kappa + Adv_EUF-CMA",
            "note": "the reduction reads the adversary's RO queries; if it "
                    "predicts H(sigma*) it must have queried sigma*, which is "
                    "a valid signature -> forgery"}


def run():
    return {
        "pmm": pmm_solvency(),
        "fraud_proof": fraud_proof(),
        "proactive_union": proactive_union(),
        "xmss_vrf": xmss_vrf_bound(),
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
