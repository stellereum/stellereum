#!/usr/bin/env python3
"""Primary Market Maker (bonding curve) mathematics.

Curve:  P(S) = P0 * (1 + S/Sc),   P0 = 0.25 USD, Sc = 125e6 STELL.

Exact integrals (all in nano-STELL / micro-USD):
  V(s)        = int_0^s P            = P0 (s + s^2/(2 Sc))
  buy(s,d)    = int_s^{s+d} P        = P0 (d + (2 s d + d^2)/(2 Sc))
  sell(s,d)   = int_{s-d}^{s} P      = P0 (d + (2 s d - d^2)/(2 Sc))

The Rust code computes sell() as P0*(d - quad), quad=(2sd-d^2)/(2Sc).
That is a SIGN ERROR: redemptions are systematically underpaid, and for
s >= ~1.5 Sc a large redemption rounds to zero ("Dust").

We also prove/verify:
  * exact solvency: with exact curve pricing the reserve equals V(S), so a full
    redemption is exactly funded (buffer = 0 is sufficient);
  * the max redeemable fraction f(s, b) under a ring-fenced buffer b, closed
    form from a quadratic;
  * optimal depth Sc* under an LVR + slippage cost model.
"""
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "pmm.json")

P0 = 250_000            # micro-USD per STELL
SC = 125_000_000 * 10**9  # nano
NANO = 10**9


def V(s):
    return P0 * (s + s * s / (2 * SC)) / NANO


def buy(s, d):
    return P0 * (d + (2 * s * d + d * d) / (2 * SC)) / NANO


def sell_correct(s, d):
    return P0 * (d + (2 * s * d - d * d) / (2 * SC)) / NANO


def sell_code(s, d):
    quad = (2 * s * d - d * d) / (2 * SC)
    return P0 * max(d - quad, 0) / NANO


def mint_for_usdt(s, u_micro):
    k = u_micro * NANO / P0
    a = s + SC
    return math.sqrt(a * a + 2 * SC * k) - a


def max_redeem_fraction(x, b):
    """Largest f with payout(f*s) <= (1-b) V(s), x = s/Sc, b in [0,1).
    Solves  x f^2 - 2(1+x) f + (1-b)(2+x) >= 0 for the smaller root."""
    disc = (1 + x) ** 2 - x * (1 - b) * (2 + x)
    if disc < 0:
        return 0.0
    return ((1 + x) - math.sqrt(disc)) / x if x > 0 else (1 - b)


def optimal_depth(sigma_daily, D, kappa=1.0):
    """Minimise the sum of LVR and user-slippage costs
        C(Sc) = (P0/2) [ sigma^2 Sc + kappa D^2 / Sc ]
    (sigma: relative daily volatility, D: typical/p99 order size in STELL).
    ->  Sc* = D sqrt(kappa) / sigma.   Units: STELL."""
    return D * math.sqrt(kappa) / sigma_daily


def run():
    out = {}
    # 1) sign-error table
    rows = []
    for frac in [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]:
        s = frac * SC
        for df in [0.1, 0.5, 0.9]:
            d = df * s
            c = sell_code(s, d)
            k = sell_correct(s, d)
            rows.append({
                "s_over_Sc": frac, "d_over_s": df,
                "code_usd": c / 1e6, "correct_usd": k / 1e6,
                "paid_ratio": (c / k if k else 0.0),
                "code_is_dust": c == 0,
            })
    out["sell_curve_audit"] = rows

    # 2) round-trip: buy u, then sell the same d
    rt = []
    for u_usd in [10_000, 1_000_000, 100_000_000, 250_000_000]:
        u = u_usd * 10**6
        d = mint_for_usdt(0, u)
        code = sell_code(d, d)
        corr = sell_correct(d, d)
        rt.append({
            "buy_usd": u_usd,
            "stell": d / NANO,
            "supply_over_Sc": d / SC,
            "sell_code_usd": code / 1e6,
            "sell_correct_usd": corr / 1e6,
            "code_loss_pct": 100 * (1 - code / u),
            "correct_loss_pct": 100 * (1 - corr / u),
        })
    out["round_trip"] = rt

    # 3) solvency + buffer
    buf = []
    for b in [0.0, 0.10, 0.20, 0.30, 0.50]:
        row = {"buffer_bps": int(b * 10_000)}
        for x in [0.0, 0.25, 0.5, 1.0, 2.0, 5.0]:
            row[f"f_max_at_s={x}Sc"] = round(max_redeem_fraction(x, b), 4) if x > 0 else 1 - b
        buf.append(row)
    out["max_redeemable_fraction"] = buf
    # exact solvency check: after buying to supply s, reserve == V(s)
    sol = []
    for u_usd in [10_000, 1_000_000, 100_000_000]:
        d = mint_for_usdt(0, u_usd * 10**6)
        full = sell_correct(d, d)
        sol.append({
            "buy_usd": u_usd,
            "full_redemption_usd": full / 1e6,
            "reserve_minus_payout_usd": (u_usd * 10**6 - full) / 1e6,
            "fully_funded": full <= u_usd * 10**6 + 1e-6,
        })
    out["solvency"] = sol

    # 4) optimal depth under LVR + slippage
    opt = []
    for sigma in [0.02, 0.05, 0.10]:
        for D in [1_000_000, 10_000_000, 125_000_000]:
            Sc = optimal_depth(sigma, D)
            opt.append({
                "sigma_daily": sigma, "order_size_stell": D,
                "Sc_star_stell": round(Sc),
                "Sc_star_over_current": round(Sc / (SC / NANO), 3),
            })
    out["optimal_depth"] = opt
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
