# P14. Работающий XMSS-VRF, refinement 2PC/witness и досье на пороговую подпись

> Три «прорывных» пункта из P12/P13: что удалось сделать, что нет.
> Код: `code/xmss_vrf.py`, `code/xpc_refinement.py`.
> Результаты: `results/xmss_vrf.json`, `results/xpc_refinement.json`.

---

## A. XMSS-VRF: работающий прототип

### A.1. Конструкция

* **WOTS+**: `w=16`, `n=32` (SHA-256), `len1=64`, `len2=3`, `len=67`.
* **XMSS**: дерево Меркла высоты `h`; лист = `epoch`.
* **VRF**: `y = H(seed ‖ σ)`, где `σ = XMSS.Sign(master, epoch, seed)`.
  Проверка: `XMSS.Verify(root, epoch, seed, σ)` и `y = H(seed ‖ σ)`.

### A.2. Что проверено (`results/xmss_vrf.json`)

| Свойство | Результат |
|---|---|
| корректность | `true` |
| детерминизм `y` и `σ` | `true` |
| неверный epoch / seed / `y` | отклоняются |
| чужой лист на этом epoch | отклоняется |
| размер подписи (h=6) | **2336 байт** (67·32 + 6·32) |
| подпись (h=6) | ~0.44 мс (дерево кэшировано) |
| grinding self-defeat | две подписи на одном листе → toy-подпись третьего сообщения **верифицируется** |

**Grinding self-defeat.** WOTS+ одноразовый: две подписи на одном листе —
публичное доказательство эквивокации, ключ сожжён. В toy-параметрах
(`n=8`, `len=18`) мы нашли третье сообщение и **подделали** подпись после
двух подписей (`forged_message = "forge-85734"`, `verifies = true`). Для
реальных `n=32` полная подделка требует подбора сообщения, но ключ всё
равно сожжён — этого достаточно для слэшинга.

**Честная оценка.** Это **работающий прототип**, не production:
* `SHA-256` вместо твикабельного хеша XMSS;
* состояние (счётчик листьев) не реализовано;
* подпись 2.3 КБ — дорого для блока, но приемлемо для beacon раз в эпоху;
* аудита нет.

---

## B. 2PC/witness: refinement-анализ и найденный gap

### B.1. Абстрактная машина (P5)

9 достижимых состояний `(source, target)`:
`(N,N) (P,N) (P,P) (P,C) (P,A) (A,N) (A,A) (C,P) (C,C)`; инварианты I1–I4
выполнены (P5).

### B.2. Конкретный witness-слой

* `CrossShardMessage` несёт `merkle_inclusion_proof`, `source_state_root`,
  `finalized_in_block`, `xpc_phase`.
* `xpc_state_key(tx_hash)` и `xpc_state_value(phase, tx_hash)` связывают
  лист с транзакцией и фазой (33 байта).
* **VALIDATE** (`src/runtime.rs:1732 xpc_admissible`) использует
  `verify_xpc_anchored`: Merkle-proof **+** `anchor_holds(source_shard,
  finalized_in_block, source_state_root)`. Вызывается на propose
  (`runtime.rs:4138`) и validate (`runtime.rs:4929`).
* **APPLY** (`src/state_engine.rs:6433-6522`) использует
  `verify_xpc_proof` — **только Merkle-proof, без anchor**.

### B.3. Обязательства refinement

```
R1  каждый блок, доходящий до apply_xpc_record, прошёл xpc_admissible
    (propose/validate) или покрыт QC честного кворума;
R2  xpc_state_key/value связывают (tx_hash, phase); лист одной фазы не
    проходит proof другой (domain separation);
R3  PatriciaTrie::verify_merkle_proof sound; SHA-256 collision-resistant;
R4  anchor_holds true только для локально финализированного заголовка
    peer-шарда;
R5  apply/reorg/sync не обходят VALIDATE.
```

R1–R4 выполнены по коду (см. таблицу соответствия фаз ниже). **R5 — gap.**

| kind | допустимые фазы в `xpc_admissible` | абстрактный guard |
|---|---|---|
| `Prepare` | account leaf **или** `Prepared` | источник подготовил/эскроу |
| `PrepareAck` | `Prepared` | цель проголосовала YES |
| `Commit` | `Prepared`, `Committed` | источник эскроу |
| `AbortRequest` | `Prepared`, `Committed` | источник эскроу |
| `AbortAck` | `Aborted` | цель никогда не готовилась |

### B.4. Gap и атака (модель)

`apply_xpc_record` проверяет proof против **того `source_state_root`,
который принёс сам msg**. Если apply-путь получает блок, не прошедший
`xpc_admissible`, атакующий:

1. строит свой trie с листом `xpc_state_key(tx) → Prepared`;
2. кладёт его корень в `source_state_root` и валидный Merkle-proof;
3. отправляет `Commit`/`AbortAck`.

`verify_xpc_proof` вернёт `true` (proof валиден против **своего** корня),
`verify_xpc_anchored` — `false` (корень не финализирован). Численно
(`results/xpc_refinement.json`):

```
apply proof-only : accepted = true,  credited = true    ← фейковый Prepared
apply anchored   : accepted = false, credited = false
```

**Это refinement gap, а не обязательно эксплуатируемая уязвимость:** если
`apply_block`/`reorg` (`runtime.rs:8315`) применяет только блоки, прошедшие
`xpc_admissible` (или финализированные QC честного кворума), R1 держит.
Но код apply-пути **сам** anchor не проверяет, поэтому R5 нужно либо
доказать инвариантом дерева блоков, либо закрыть защитой в глубину:

```rust
// в apply_xpc_record вместо verify_xpc_proof:
if !msg.verify_xpc_anchored(registry, &[phase]) { return false; }
```

(или повторный `xpc_admissible`).

**Вывод B.** Автомат и witness-слой корректны **при условии R1**; главный
незакрытый пункт — дисциплина apply/reorg. Это ровно тот refinement,
которого не хватало в P5.

---

## C. Пороговая/агрегируемая подпись: досье

### C.1. Почему это не «ещё один модуль»

1. **Falcon не агрегируется.** Подписи — короткие векторы решётки, проверка
   нелинейна по норме; сложить нельзя.
2. **Наивная линейная агрегация** даёт `‖Σσ‖ ~ √k β` и теряет
   `≈ ½ log2 k` бит (P11 E1): при `k=64` — 3 бита, при `k=1024` — 5.
3. **Пороговый Falcon/ML-DSA** — research: ловушка Falcon — матрица, а не
   скаляр, Shamir напрямую не применим.
4. **STARK-агрегация** работает (P10 C), но при `k=64` проигрывает сырым
   подписям; выигрывает при `k≥300`.

### C.2. Что реально можно сделать (план)

| Вариант | Статус | Что делать |
|---|---|---|
| STARK над проверкой `k` Falcon | инженерный | измерить prover/verifier, `k*=(S+32)/666` |
| Threshold ML-KEM (для MEV) | research | пороговая LWE-схема; пока Shamir/GF(256)+PQ |
| Threshold Falcon | open | не обещать; следить за литературой |
| XMSS-агрегация | не агрегат | сертификат из `k` XMSS = `k·2.3КБ`, хуже Falcon |

**Вывод C.** Работающая **пороговая** подпись — это отдельный research-проект
(месяцы, не дни). Работающий **PQ-VRF** — сделали (A). Практичный
**агрегат** для QC — STARK, но только при больших `k`.

---

## D. Что это даёт

1. **PQ-VRF**: есть работающий прототип XMSS-VRF (2.3 КБ, детерминизм,
   self-defeat grinding). Можно ставить в beacon раз в эпоху; нужен аудит
   и stateful-счётчик.
2. **2PC**: формализованы R1–R5; найден **apply-vs-validate gap**
   (`verify_xpc_proof` без anchor). Это конкретный пункт для аудита/фикса.
3. **Порог**: честно очерчены границы; не выдаём research за продукт.

## E. Следующие шаги

1. Закрыть R5: `verify_xpc_anchored` в apply-пути + тест с фейковым
   `source_state_root`.
2. XMSS-VRF: stateful leaf counter, твикабельный хеш, аудит, замер в beacon.
3. STARK-агрегация: прототип на `k=64/300/1000`, замер `S` и prover time.
