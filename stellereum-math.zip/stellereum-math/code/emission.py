#!/usr/bin/env python3
"""Tokenomics: emission exhaustion, block-time consistency, and a cap-exact
geometric schedule.

Facts from the code (src/tokenomics.rs):
  pool        P = 350,000,000 STELL
  reward      R = 0.317 STELL per block (BLOCK_REWARD_NANO = 317e6 nano)
  cap         total supply 1,000,000,000 STELL

Exhaustion height  H* = P/R  (floored), exhaustion time T* = H* * block_time.
The tokenomics comment assumes 200 ms blocks; the README targets 0.6 s.
"""
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "emission.json")

P = 350_000_000.0      # STELL reward pool
R = 0.317              # STELL / block
SEC_PER_YEAR = 31_536_000.0


def exhaust(block_time):
    h = P / R
    return h, h * block_time / SEC_PER_YEAR


def geometric_schedule(N, R0):
    """Solve R0 * (1 - lam^N)/(1 - lam) = P for lam in (0,1).
    Returns (lam, total_check)."""
    if R0 * N <= P:
        return 1.0, R0 * N  # no decay needed (or over-spend)
    lo, hi = 1e-12, 1.0
    for _ in range(200):
        mid = (lo + hi) / 2
        total = R0 * (1 - mid ** N) / (1 - mid)
        if total > P:
            hi = mid      # total is decreasing in lambda
        else:
            lo = mid
    lam = (lo + hi) / 2
    return lam, R0 * (1 - lam ** N) / (1 - lam)


def half_life_schedule(H):
    """R_h = R0 * 2^(-h/H); total from h=0..inf = R0*H/ln2 = P -> R0."""
    return P * math.log(2) / H


def run():
    out = {"pool": P, "reward": R, "blocks_to_exhaust": P / R}
    rows = []
    for bt in [0.2, 0.25, 0.6, 1.0, 3.0]:
        h, yrs = exhaust(bt)
        rows.append({
            "block_time_s": bt,
            "exhaust_height": h,
            "exhaust_years": round(yrs, 3),
            "annual_emission_stell": round(R * SEC_PER_YEAR / bt, 0),
        })
    out["exhaustion_by_block_time"] = rows

    # cap-exact schedules for a T-year horizon.
    # Half-life (geometric-to-infinity) schedule:
    #   R_h = R0 * 2^(-h/H),  sum_{h>=0} R_h = R0 / (1 - 2^(-1/H)) = P
    #   => R0 = P * (1 - 2^(-1/H)).
    # Time to emit the fraction q of the pool: h_q = H * log2(1/(1-q)).
    # So to emit 99% within T years choose H = T / log2(100) = T/6.6439.
    sched = []
    for bt in [0.2, 0.6]:
        for horizon in [7, 10, 20]:
            N = int(horizon * SEC_PER_YEAR / bt)
            flat = P / N
            H_years = horizon / math.log2(100.0)
            H = H_years * SEC_PER_YEAR / bt
            r = 2.0 ** (-1.0 / H)
            R0_h = P * (1.0 - r)
            total = R0_h / (1.0 - r)
            sched.append({
                "block_time_s": bt,
                "horizon_years": horizon,
                "blocks": N,
                "flat_reward_stell": flat,
                "current_reward_stell": R,
                "current_exhaust_years": round(P / R * bt / SEC_PER_YEAR, 2),
                "half_life_years": round(H_years, 3),
                "half_life_R0_stell": R0_h,
                "checksum_total_infinity": total,
                "emit_99pct_by_years": round(H_years * math.log2(100.0), 3),
            })
    out["cap_exact_schedules"] = sched

    # inflation rate at genesis and at 50% of pool
    infl = []
    for remaining in [1.0, 0.5, 0.25]:
        annual = R * SEC_PER_YEAR / 0.6
        out_so_far = P * (1 - remaining)
        circulating = 250_000_000 + out_so_far  # genesis vault + emitted
        infl.append({
            "pool_fraction_remaining": remaining,
            "circulating_stell": circulating,
            "annual_emission_stell": round(annual),
            "inflation_pct": round(100 * annual / circulating, 3),
        })
    out["inflation_at_0.6s"] = infl
    return out


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
