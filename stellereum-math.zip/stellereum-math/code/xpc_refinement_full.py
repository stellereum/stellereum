#!/usr/bin/env python3
"""Finite-state refinement proof for the 2PC witness layer.

Abstract machine (P5): (s,t) in {N,P,C,A}^2 with message guards; 8 reachable
states, safety invariants I1-I4.

Concrete machine: the same phases plus (credit, refund) counters.  A message
carries a claimed peer phase q and a proof.  Two verification modes:

  ANCHORED (runtime::xpc_admissible):
      the proof is checked against a FINALIZED peer root, so q must equal the
      peer's actual phase.
  PROOF-ONLY (state_engine::apply_xpc_record):
      the proof is checked against the message's own source_state_root, which
      the attacker controls, so q is arbitrary (a fake root).

We enumerate both machines exhaustively and show:
  * ANCHORED: every reachable projection is one of the 8 abstract states,
    credit <= 1, refund <= 1, and never (s=A & t=C & credit & refund);
  * PROOF-ONLY: (N,C) with credit (a mint) and (A,C) with credit+refund
    (a double spend) are reachable.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "xpc_refinement_full.json")

N, P, C, A = "N", "P", "C", "A"


def abstract_reachable():
    start = (N, N)
    seen = {start}
    frontier = [start]
    while frontier:
        s, t = frontier.pop()
        moves = []
        if s == N:
            moves.append((P, t))
        if s in (P, C) and t in (N, P):
            moves.append((s, P))
        if s == P and t in (P, C):
            moves.append((C, t))
        if s == P and t in (N, A):
            moves.append((A, t))
        if s in (P, C) and t == P:
            # the target credits on the source's PREPARED or COMMITTED leaf
            moves.append((s, C))
        if s in (P, A) and t == N:
            moves.append((s, A))
        for m in moves:
            if m not in seen:
                seen.add(m)
                frontier.append(m)
    return seen


def concrete_reachable(anchored):
    """State: (s, t, credit, refund)."""
    start = (N, N, 0, 0)
    seen = {start}
    frontier = [start]
    while frontier:
        s, t, cr, rf = frontier.pop()

        def add(ns, nt, ncr, nrf):
            if (ns, nt, ncr, nrf) not in seen:
                seen.add((ns, nt, ncr, nrf))
                frontier.append((ns, nt, ncr, nrf))

        # source PREPARE (local escrow)
        if s == N:
            add(P, t, cr, rf)
        # target PREPARE: opening account proof (source has escrowed: s=P) or
        # the source's PREPARED leaf.  Anchored requires s in {P,C}; the
        # proof-only attack can claim P with a fake root.
        if t == N:
            if anchored:
                if s in (P, C):
                    add(s, P, cr, rf)
            else:
                add(s, P, cr, rf)
        # source receives PREPARE-ACK (target voted YES)
        if s == P and cr == 0:
            if anchored:
                if t in (P, C):
                    add(C, t, cr, rf)
            else:
                add(C, t, cr, rf)
        # source receives ABORT-ACK (target never prepared)
        if s == P and rf == 0:
            if anchored:
                if t in (N, A):
                    add(A, t, cr, rf + 1)
            else:
                add(A, t, cr, rf + 1)
        # target COMMIT -> credit
        if t == P and cr == 0:
            if anchored:
                if s in (P, C):
                    add(s, C, cr + 1, rf)
            else:
                add(s, C, cr + 1, rf)
        # target ABORT-REQUEST (source never prepared)
        if t == N:
            if anchored:
                if s in (P, C):
                    add(s, A, cr, rf)
            else:
                add(s, A, cr, rf)
    return seen


def check(anchored):
    states = concrete_reachable(anchored)
    abs_states = abstract_reachable()
    violations = []
    for (s, t, cr, rf) in states:
        if (s, t) not in abs_states:
            violations.append({"state": [s, t], "credit": cr, "refund": rf,
                               "kind": "projection not in abstract reachable"})
        if cr > 1 or rf > 1:
            violations.append({"state": [s, t], "credit": cr, "refund": rf,
                               "kind": "double credit/refund"})
        if s == A and t == C and cr == 1 and rf == 1:
            violations.append({"state": [s, t], "credit": cr, "refund": rf,
                               "kind": "double spend"})
        if s == N and t == C and cr == 1:
            violations.append({"state": [s, t], "credit": cr, "refund": rf,
                               "kind": "mint without source"})
    return {
        "mode": "anchored" if anchored else "proof-only",
        "state_count": len(states),
        "violations": violations[:20],
        "violation_count": len(violations),
        "safe": len(violations) == 0,
    }


def run():
    anchored = check(True)
    proof_only = check(False)
    return {
        "abstract_states": sorted([list(x) for x in abstract_reachable()]),
        "anchored": anchored,
        "proof_only": proof_only,
        "theorem": "ANCHORED concrete machine refines the abstract machine; "
                   "PROOF-ONLY does not.",
        "counterexample": next((v for v in proof_only["violations"]
                                if v["kind"] in ("mint without source",
                                                 "double spend")), None),
    }


if __name__ == "__main__":
    r = run()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(r, f, indent=2)
    print(json.dumps(r, indent=2))
